/* JetStream curriculum, from the JetStream club presentation.
   Edit topics here; the Curriculum page is generated from this list.
   def  = the club's own definition (shown highlighted)
   try  = optional link into the Wind Tunnel simulator */
window.JETSTREAM_CURRICULUM = [
  {
    id: "foundation", level: "Foundation", title: "Our Course Plan: Foundations", color: "#ffc83d",
    summary: "The core ideas every member learns first: what keeps an aircraft in the air and what it is made of.",
    topics: [
      { t: "The four forces of flight", p: "Lift, weight, thrust and drag. In steady flight lift balances weight and thrust balances drag; change the balance and the aircraft climbs, descends, speeds up or slows down." },
      { t: "Newton's laws and flight", p: "A wing pushes air downward, so the air pushes the wing upward (third law). Thrust accelerates the aircraft (second law), and when all forces balance it flies steadily (first law)." },
      { t: "Lift and drag", p: "Lift acts at right angles to the oncoming air; drag acts along it. Both grow with the square of speed: F = ½ ρ v² C A.", try: ["wind-tunnel.html?shape=naca4412&v=30&aoa=4", "See lift and drag in the wind tunnel"] },
      { t: "Airfoils", def: "A streamlined shape designed to produce more lift than drag when air moves past it.", p: "We compare symmetric and cambered airfoils (NACA 0012 vs NACA 4412) and see how shape changes lift.", try: ["wind-tunnel.html?shape=naca0012&v=25&aoa=5", "Compare airfoils in the wind tunnel"] },
      { t: "Angle of attack", def: "The angle between a wing's chord line (an imaginary straight line from the front edge to the back edge of the wing) and the relative wind (the direction of the air moving past the wing).", p: "More angle means more lift, until the flow separates and the wing stalls.", try: ["wind-tunnel.html?shape=naca0012&v=25&aoa=20", "Stall a wing in the wind tunnel"] },
      { t: "Stability and control", p: "How an aircraft stays steady in the air, and how the pilot changes its attitude in pitch, roll and yaw." },
      { t: "Aircraft components", def: "What a fuselage is, what a wing is, and the science behind how each one functions and is designed.", p: "We also cover the tail (empennage), control surfaces, landing gear and the powerplant." },
      { t: "Why different aircraft have different designs", p: "Gliders have long slender wings, fighters have swept or delta wings, airliners are built for fuel efficiency. Every shape is a trade-off for a mission." },
      { t: "Introduction to propulsion", p: "Propellers, jet engines and rockets all make thrust the same way: by throwing air or exhaust backwards so the aircraft is pushed forwards." }
    ]
  },
  {
    id: "intermediate", level: "Intermediate", title: "Our Course Plan: Studying the Aircraft", color: "#ff7a2f",
    summary: "A closer look at how real aircraft are sized, balanced, controlled and powered.",
    topics: [
      { t: "Wing loading", p: "The aircraft's weight divided by its wing area. Low wing loading means slow, gentle flight (gliders); high wing loading means fast flight and higher take-off speeds." },
      { t: "Aspect ratio", def: "The measure of a wing's length (wingspan) relative to its width (chord).", p: "AR = b² / S. Long, thin, high-aspect-ratio wings create less induced drag, which is why gliders have them.", try: ["wind-tunnel.html?shape=naca4412&v=20&aoa=6&L=0.3&b=0.6", "Change the aspect ratio in the wind tunnel"] },
      { t: "Centre of gravity", p: "The point where the aircraft's weight acts. Where it sits relative to the wing decides whether the aircraft is stable, which is why we balance our gliders before flying them." },
      { t: "Static stability", def: "The initial tendency of a body or system to return to its original position or equilibrium state after being disturbed." },
      { t: "Control surfaces", p: "Ailerons (roll), elevator (pitch), rudder (yaw), plus flaps and slats for extra lift at low speed, and trim tabs." },
      { t: "Propeller design", p: "A propeller is a rotating wing. Blade pitch, twist, diameter and the number of blades all change how much thrust it makes and how efficiently." },
      { t: "Fuselage design", p: "The fuselage carries the crew, passengers and payload. It must be strong, light and streamlined to keep drag low." },
      { t: "Aerodynamic efficiency", p: "Measured by the lift-to-drag ratio (L/D): how much lift a design gets for each unit of drag. Higher L/D means longer glides and less fuel burned.", try: ["wind-tunnel.html?shape=naca4412&v=12&aoa=4&L=0.15&b=1.2", "Find the best L/D in the wind tunnel"] },
      { t: "How jet engines work", def: "Turbofans and GTEs: Gas Turbine Engines.", p: "Suck, squeeze, bang, blow: air is drawn in, compressed, burned with fuel, and blasted out of the back to make thrust." },
      { t: "Parts of a jet engine", p: "Fan, compressor, combustion chamber, turbine and nozzle, and how bypass air makes modern turbofans quieter and more efficient." }
    ]
  },
  {
    id: "advanced", level: "Advanced", title: "Our Course Plan: Space and Propulsion", color: "#e63946",
    summary: "Beyond the atmosphere: rockets, orbits, spacecraft and where aerospace is heading next.",
    topics: [
      { t: "How rockets generate thrust", p: "A rocket throws hot exhaust gas out of its nozzle at very high speed and is pushed the other way. It carries its own oxidiser, so it works in the vacuum of space." },
      { t: "Rocket staging", p: "Dropping empty tanks and engines during flight so the rocket doesn't keep carrying dead weight. That is how multi-stage rockets reach orbit." },
      { t: "Escape velocity", p: "The speed needed to break free of a planet's gravity without further thrust: v = √(2GM / r), about 11.2 km/s for Earth." },
      { t: "Satellites", p: "A satellite is always falling towards Earth but moving sideways fast enough (about 7.8 km/s in low orbit) to keep missing it. Used for communication, weather, navigation and observation." },
      { t: "Re-entry", def: "Works by using the friction and compression of Earth's air as a giant brake to slow down a fast-moving spacecraft.", p: "Heat shields and blunt shapes protect the spacecraft from temperatures of thousands of degrees." },
      { t: "Spacecraft design", p: "Power, thermal control, communications, structure and payload, designed to survive vacuum, radiation and huge temperature swings." },
      { t: "Planetary missions", p: "How missions travel to other worlds: transfer orbits, gravity assists, orbiters, landers and rovers." },
      { t: "Future aerospace technologies", p: "Electric and hydrogen aircraft, sustainable aviation fuels, reusable rockets, air taxis and the return of supersonic travel." }
    ]
  }
];

/* =========================================================
   JetStream data layer: accounts, members, lectures, posts.
   Two interchangeable backends with the same API:
     - local    : localStorage (preview / testing on one computer)
     - firebase : Firebase Auth + Firestore (real, shared, secure via rules)
   All methods return Promises.
   ========================================================= */
(function () {
  "use strict";
  var CFG = window.JETSTREAM_CONFIG || {};
  var listeners = [];
  var current = null;
  var api = {};

  function notify() { listeners.forEach(function (fn) { try { fn(current); } catch (e) { console.error(e); } }); }
  function nowISO() { return new Date().toISOString(); }
  function byDateDesc(k) { return function (a, b) { return String(b[k] || "").localeCompare(String(a[k] || "")); }; }
  function clean(s, max) { return String(s == null ? "" : s).trim().slice(0, max || 500); }
  function validEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

  // ------------------------------------------------------------------ LOCAL
  function LocalBackend() {
    var KEY = "jetstream_db_v1", SKEY = "jetstream_session_v1";
    function load() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } }
    function save(db) { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { console.warn("Storage unavailable", e); } }
    function uid() { return "u_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }
    async function hash(pw, salt) {
      var data = salt + "|" + pw;
      if (window.crypto && crypto.subtle) {
        var buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(data));
        return Array.from(new Uint8Array(buf)).map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
      }
      var h = 0; for (var i = 0; i < data.length; i++) { h = (h * 31 + data.charCodeAt(i)) | 0; } return "x" + h;
    }
    var db = load();

    async function seed() {
      db = { members: [], auth: {}, lectures: [], posts: [] };
      var a = CFG.localDemoAdmin;
      if (a) {
        var id = uid(), salt = Math.random().toString(36).slice(2);
        db.members.push({ id: id, name: a.name, email: a.email.toLowerCase(), grade: "", role: "admin", showPublic: false, joined: nowISO() });
        db.auth[a.email.toLowerCase()] = { uid: id, salt: salt, hash: await hash(a.password, salt) };
      }
      db.lectures.push({
        id: uid(), sample: true, title: "Sample: How do jet engines work?", speaker: "Speaker to be announced",
        affiliation: "Aerospace industry guest", date: "", description: "This is a sample entry so you can see the layout. Admins can delete it and add real guest lectures from the Admin page.", created: nowISO()
      });
      db.posts.push({
        id: uid(), title: "Welcome to JetStream, Heritage's first aerospace club",
        author: "JetStream Club Leaders", date: nowISO().slice(0, 10),
        body: "JetStream is a student-led club where we explore the design aspects of aircraft, their key components, and the science behind how they fly.\n\nWe start with the Foundations course (the four forces of flight, Newton's laws, airfoils and angle of attack), then move on to studying aircraft in depth, and finally space and propulsion.\n\nAlong the way we will run a paper/glider design challenge, test different wing designs, and build a water-rocket-style experiment together. This blog will document everything we design and learn.",
        created: nowISO()
      });
      save(db);
    }

    function sessionUser() {
      var sid = null; try { sid = localStorage.getItem(SKEY); } catch (e) {}
      if (!sid || !db) return null;
      var m = db.members.find(function (x) { return x.id === sid; });
      return m ? Object.assign({ uid: m.id, isAdmin: m.role === "admin" }, m) : null;
    }
    function requireAdmin() { if (!current || !current.isAdmin) throw new Error("Only admins can do that."); }

    return {
      mode: "local",
      init: async function () { if (!db || !db.members) await seed(); current = sessionUser(); },
      signUp: async function (d) {
        var email = clean(d.email, 200).toLowerCase();
        if (!clean(d.name)) throw new Error("Please enter your name.");
        if (!validEmail(email)) throw new Error("Please enter a valid email.");
        if (!d.password || d.password.length < 6) throw new Error("Password must be at least 6 characters.");
        if (db.auth[email]) throw new Error("An account with this email already exists. Try signing in.");
        var id = uid(), salt = Math.random().toString(36).slice(2);
        db.members.push({ id: id, name: clean(d.name, 120), email: email, grade: clean(d.grade, 40), interests: d.interests || [], role: "member", showPublic: !!d.showPublic, joined: nowISO() });
        db.auth[email] = { uid: id, salt: salt, hash: await hash(d.password, salt) };
        save(db);
        try { localStorage.setItem(SKEY, id); } catch (e) {}
        current = sessionUser(); notify(); return current;
      },
      signIn: async function (email, pw) {
        email = clean(email, 200).toLowerCase();
        var rec = db.auth[email];
        if (!rec || rec.hash !== await hash(pw || "", rec.salt)) throw new Error("Wrong email or password.");
        if (!db.members.some(function (m) { return m.id === rec.uid; })) throw new Error("This account was removed by an admin.");
        try { localStorage.setItem(SKEY, rec.uid); } catch (e) {}
        current = sessionUser(); notify(); return current;
      },
      signOut: async function () { try { localStorage.removeItem(SKEY); } catch (e) {} current = null; notify(); },
      listDirectory: async function () {
        return db.members.filter(function (m) { return m.showPublic; })
          .map(function (m) { return { id: m.id, name: m.name, grade: m.grade, role: m.role, joined: m.joined }; })
          .sort(function (a, b) { return a.name.localeCompare(b.name); });
      },
      listMembers: async function () { requireAdmin(); return db.members.slice().sort(byDateDesc("joined")); },
      addMember: async function (d) {
        requireAdmin();
        if (!clean(d.name)) throw new Error("Name is required.");
        var email = clean(d.email, 200).toLowerCase();
        if (email && db.members.some(function (m) { return m.email === email; })) throw new Error("A member with this email already exists.");
        var m = { id: uid(), name: clean(d.name, 120), email: email, grade: clean(d.grade, 40), role: d.role === "admin" ? "admin" : "member", showPublic: !!d.showPublic, joined: nowISO(), addedByAdmin: true };
        db.members.push(m); save(db); return m;
      },
      deleteMember: async function (id) {
        requireAdmin();
        if (current && id === current.uid) throw new Error("You can't delete your own account while signed in.");
        var m = db.members.find(function (x) { return x.id === id; });
        db.members = db.members.filter(function (x) { return x.id !== id; });
        if (m && m.email && db.auth[m.email]) delete db.auth[m.email];
        save(db);
      },
      setRole: async function (id, role) {
        requireAdmin();
        if (current && id === current.uid && role !== "admin") throw new Error("You can't remove your own admin role.");
        var m = db.members.find(function (x) { return x.id === id; }); if (m) { m.role = role === "admin" ? "admin" : "member"; save(db); }
      },
      list: async function (col) { return (db[col] || []).slice().sort(byDateDesc(col === "posts" ? "date" : "created")); },
      add: async function (col, data) { requireAdmin(); var item = Object.assign({ id: uid(), created: nowISO() }, data); db[col].push(item); save(db); return item; },
      remove: async function (col, id) { requireAdmin(); db[col] = db[col].filter(function (x) { return x.id !== id; }); save(db); }
    };
  }

  // --------------------------------------------------------------- FIREBASE
  function FirebaseBackend() {
    var V = "10.12.2", auth, fs;
    function loadScript(src) {
      return new Promise(function (res, rej) { var s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = function () { rej(new Error("Could not load " + src)); }; document.head.appendChild(s); });
    }
    async function profile(u) {
      var snap = await fs.collection("members").doc(u.uid).get();
      var d = snap.exists ? snap.data() : { name: u.email, role: "member" };
      return Object.assign({ uid: u.uid, id: u.uid, email: u.email }, d, { isAdmin: d.role === "admin" });
    }
    function requireAdmin() { if (!current || !current.isAdmin) throw new Error("Only admins can do that."); }
    function friendly(e) {
      var map = {
        "auth/email-already-in-use": "An account with this email already exists. Try signing in.",
        "auth/invalid-email": "Please enter a valid email.",
        "auth/weak-password": "Password must be at least 6 characters.",
        "auth/invalid-credential": "Wrong email or password.",
        "auth/wrong-password": "Wrong email or password.",
        "auth/user-not-found": "Wrong email or password.",
        "permission-denied": "You don't have permission to do that."
      };
      return new Error(map[e && e.code] || (e && e.message) || "Something went wrong.");
    }
    function docs(snap) { return snap.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); }); }

    return {
      mode: "firebase",
      init: async function () {
        var base = "https://www.gstatic.com/firebasejs/" + V + "/";
        await loadScript(base + "firebase-app-compat.js");
        await Promise.all([loadScript(base + "firebase-auth-compat.js"), loadScript(base + "firebase-firestore-compat.js")]);
        firebase.initializeApp(CFG.firebase);
        auth = firebase.auth(); fs = firebase.firestore();
        await new Promise(function (resolve) {
          var first = true;
          auth.onAuthStateChanged(async function (u) {
            try { current = u ? await profile(u) : null; } catch (e) { current = null; }
            if (first) { first = false; resolve(); } else notify();
          });
        });
      },
      signUp: async function (d) {
        if (!clean(d.name)) throw new Error("Please enter your name.");
        try {
          var cred = await auth.createUserWithEmailAndPassword(clean(d.email, 200), d.password);
          var u = cred.user, joined = nowISO();
          await fs.collection("members").doc(u.uid).set({ name: clean(d.name, 120), email: u.email, grade: clean(d.grade, 40), interests: d.interests || [], role: "member", showPublic: !!d.showPublic, joined: joined });
          if (d.showPublic) await fs.collection("directory").doc(u.uid).set({ name: clean(d.name, 120), grade: clean(d.grade, 40), role: "member", joined: joined });
          current = await profile(u); notify(); return current;
        } catch (e) { throw friendly(e); }
      },
      signIn: async function (email, pw) {
        try { var c = await auth.signInWithEmailAndPassword(clean(email, 200), pw); current = await profile(c.user); notify(); return current; }
        catch (e) { throw friendly(e); }
      },
      signOut: async function () { await auth.signOut(); current = null; notify(); },
      listDirectory: async function () { return docs(await fs.collection("directory").get()).sort(function (a, b) { return a.name.localeCompare(b.name); }); },
      listMembers: async function () { requireAdmin(); try { return docs(await fs.collection("members").get()).sort(byDateDesc("joined")); } catch (e) { throw friendly(e); } },
      addMember: async function (d) {
        requireAdmin();
        try {
          var ref = fs.collection("members").doc(), joined = nowISO();
          var m = { name: clean(d.name, 120), email: clean(d.email, 200).toLowerCase(), grade: clean(d.grade, 40), role: d.role === "admin" ? "admin" : "member", showPublic: !!d.showPublic, joined: joined, addedByAdmin: true };
          await ref.set(m);
          if (m.showPublic) await fs.collection("directory").doc(ref.id).set({ name: m.name, grade: m.grade, role: m.role, joined: joined });
          return Object.assign({ id: ref.id }, m);
        } catch (e) { throw friendly(e); }
      },
      deleteMember: async function (id) {
        requireAdmin();
        if (current && id === current.uid) throw new Error("You can't delete your own account while signed in.");
        try { await fs.collection("directory").doc(id).delete(); await fs.collection("members").doc(id).delete(); } catch (e) { throw friendly(e); }
      },
      setRole: async function (id, role) {
        requireAdmin();
        if (current && id === current.uid && role !== "admin") throw new Error("You can't remove your own admin role.");
        role = role === "admin" ? "admin" : "member";
        try {
          await fs.collection("members").doc(id).update({ role: role });
          var dref = fs.collection("directory").doc(id); var ds = await dref.get(); if (ds.exists) await dref.update({ role: role });
        } catch (e) { throw friendly(e); }
      },
      list: async function (col) { return docs(await fs.collection(col).get()).sort(byDateDesc(col === "posts" ? "date" : "created")); },
      add: async function (col, data) { requireAdmin(); try { var item = Object.assign({ created: nowISO() }, data); var ref = await fs.collection(col).add(item); return Object.assign({ id: ref.id }, item); } catch (e) { throw friendly(e); } },
      remove: async function (col, id) { requireAdmin(); try { await fs.collection(col).doc(id).delete(); } catch (e) { throw friendly(e); } }
    };
  }

  // ------------------------------------------------------------- PUBLIC API
  var useFirebase = CFG.backend === "firebase" && CFG.firebase && CFG.firebase.apiKey;
  var impl = useFirebase ? FirebaseBackend() : LocalBackend();
  api.mode = impl.mode;
  api.ready = impl.init().catch(function (e) { console.error("JetStream store failed to start:", e); });
  api.user = function () { return current; };
  api.onChange = function (fn) { listeners.push(fn); };
  ["signUp", "signIn", "signOut", "listDirectory", "listMembers", "addMember", "deleteMember", "setRole", "list", "add", "remove"].forEach(function (k) {
    api[k] = function () { var args = arguments; return api.ready.then(function () { return impl[k].apply(null, args); }); };
  });
  api.esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  api.initials = function (name) { return String(name || "?").trim().split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).slice(0, 2).join("").toUpperCase(); };
  window.JetStore = api;
})();

/* =========================================================
   JetStream: shared layout + site-wide behaviour
   Header/footer live here once so every page stays in sync.
   Requires js/config.js and js/store.js to be loaded first.
   ========================================================= */
(function () {
  "use strict";
  var CFG = window.JETSTREAM_CONFIG || {};
  var Store = window.JetStore;
  var esc = Store ? Store.esc : function (s) { return s; };

  var PAGES = [
    { id: "home", href: "index.html", label: "Home" },
    { id: "about", href: "about.html", label: "About" },
    { id: "curriculum", href: "curriculum.html", label: "Curriculum" },
    { id: "projects", href: "projects.html", label: "Projects" },
    { id: "lectures", href: "lectures.html", label: "Lectures" },
    { id: "members", href: "members.html", label: "Members" },
    { id: "blog", href: "blog.html", label: "Blog" },
    { id: "tunnel", href: "wind-tunnel.html", label: "Wind Tunnel" }
  ];
  var page = document.body.getAttribute("data-page") || "";

  var SOCIAL_ICONS = {
    instagram: ['Instagram', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>'],
    youtube: ['YouTube', '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23 7.2a3 3 0 0 0-2.1-2.1C19 4.6 12 4.6 12 4.6s-7 0-8.9.5A3 3 0 0 0 1 7.2 31 31 0 0 0 .6 12 31 31 0 0 0 1 16.8a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1 31 31 0 0 0 .4-4.8 31 31 0 0 0-.4-4.8zM9.7 15.1V8.9L15.5 12z"/></svg>'],
    linkedin: ['LinkedIn', '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9h4v12H3zM9 9h3.8v1.7h.1c.5-1 1.8-2 3.7-2 4 0 4.7 2.6 4.7 6V21h-4v-5.6c0-1.3 0-3-1.9-3s-2.2 1.5-2.2 2.9V21H9z"/></svg>'],
    x: ['X', '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.8 3h3.1l-6.8 7.8 8 10.2h-6.3l-4.9-6.4L5.3 21H2.2l7.3-8.3L1.8 3h6.4l4.4 5.8zm-1.1 16.2h1.7L7.4 4.7H5.6z"/></svg>'],
    email: ['Email', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>']
  };

  function socialHTML() {
    var s = CFG.social || {}, out = "";
    Object.keys(SOCIAL_ICONS).forEach(function (k) {
      if (!s[k]) return;
      var href = k === "email" ? "mailto:" + s[k] : s[k];
      out += '<a href="' + esc(href) + '" target="_blank" rel="noopener" aria-label="' + SOCIAL_ICONS[k][0] + '" title="' + SOCIAL_ICONS[k][0] + '">' + SOCIAL_ICONS[k][1] + "</a>";
    });
    return out ? '<div class="social">' + out + "</div>" : "";
  }

  function brand() {
    return '<a class="brand" href="index.html" aria-label="JetStream home"><img src="assets/logo.png" alt="">' +
      '<span class="brand-text"><strong>JetStream</strong><small>' + 'Aerospace Club</small></span></a>';
  }

  function authLinks(user) {
    if (!user) {
      return '<a href="login.html"' + (page === "login" ? ' class="active"' : "") + ">Sign in</a>" +
        '<a class="btn btn-sm" href="join.html">Join the Club</a>';
    }
    var first = String(user.name || "").split(" ")[0] || "Member";
    return (user.isAdmin ? '<a href="admin.html"' + (page === "admin" ? ' class="active"' : "") + ">Admin</a>" : "") +
      '<span class="nav-user" style="padding:8px 10px">Hi, ' + esc(first) + "</span>" +
      '<button class="linklike" id="nav-signout" type="button">Sign out</button>';
  }

  function header() {
    var links = PAGES.map(function (p) {
      return '<a href="' + p.href + '"' + (p.id === page ? ' class="active" aria-current="page"' : "") + ">" + p.label + "</a>";
    }).join("");
    return (
      '<a class="skip" href="#main">Skip to content</a>' +
      '<header class="site-header"><div class="topbar"></div><div class="wrap nav">' + brand() +
      '<button class="nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="nav-links"><span></span><span></span><span></span></button>' +
      '<nav class="nav-links" id="nav-links" aria-label="Main">' + links + '<span id="nav-auth" style="display:contents">' + authLinks(null) + "</span></nav>" +
      "</div></header>"
    );
  }

  function footer() {
    var year = new Date().getFullYear();
    return (
      '<footer class="site-footer"><div class="wrap">' +
      '<div class="footer-grid">' +
      "<div>" + brand() +
      "<p>" + esc(CFG.school || "Our school") + "'s first aerospace club. Student-led, learning the design, components and science of flight.</p>" + socialHTML() + "</div>" +
      '<div><h4>Club</h4><ul><li><a href="about.html">About Us</a></li><li><a href="members.html">Members</a></li><li><a href="lectures.html">Guest Lectures</a></li><li><a href="blog.html">Blog</a></li><li><a href="join.html">Join JetStream</a></li></ul></div>' +
      '<div><h4>Learn</h4><ul><li><a href="curriculum.html#foundation">Foundation level</a></li><li><a href="curriculum.html#intermediate">Intermediate level</a></li><li><a href="curriculum.html#advanced">Advanced level</a></li><li><a href="research.html">Research Hub</a></li></ul></div>' +
      '<div><h4>Build</h4><ul><li><a href="projects.html">Projects</a></li><li><a href="wind-tunnel.html">Wind Tunnel</a></li><li><a href="login.html">Member sign in</a></li></ul></div>' +
      "</div>" +
      '<div class="footer-bottom"><span>&copy; ' + year + " JetStream Aerospace Club, " + esc(CFG.school || "") + ".</span><span>A student-led club</span></div>" +
      "</div></footer>"
    );
  }

  var h = document.getElementById("site-header");
  if (h) h.outerHTML = header();
  var f = document.getElementById("site-footer");
  if (f) f.outerHTML = footer();

  function renderAuth() {
    var slot = document.getElementById("nav-auth");
    if (!slot || !Store) return;
    slot.innerHTML = authLinks(Store.user());
    var so = document.getElementById("nav-signout");
    if (so) so.addEventListener("click", function () {
      Store.signOut().then(function () { if (page === "admin") location.href = "index.html"; });
    });
  }
  if (Store) { Store.ready.then(renderAuth); Store.onChange(renderAuth); }

  // Mobile nav
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("nav-links");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    });
  }

  // Reveal on scroll
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    reveals.forEach(function (el) { io.observe(el); });
  } else reveals.forEach(function (el) { el.classList.add("in"); });

  // Leaders (any element with data-leaders renders the team cards)
  document.querySelectorAll("[data-leaders]").forEach(function (el) {
    el.innerHTML = (CFG.leaders || []).map(function (l) {
      var av = l.photo ? '<img src="' + esc(l.photo) + '" alt="">' : esc(Store ? Store.initials(l.name) : "");
      return '<article class="card person"><div class="avatar">' + av + "</div><h3>" + esc(l.name) + '</h3><div class="role">' + esc(l.role) + "</div>" +
        (l.bio ? "<p>" + esc(l.bio) + "</p>" : "") + "</article>";
    }).join("");
  });

  // ---------------- Hero "jetstream" animation (home page) ----------------
  var hc = document.getElementById("hero-canvas");
  if (hc) {
    var hctx = hc.getContext("2d");
    var W = 0, H = 0, dpr = 1, parts = [];
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = hc.clientWidth; H = hc.clientHeight;
      hc.width = W * dpr; hc.height = H * dpr;
      hctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var n = Math.round(Math.min(420, (W * H) / 3200));
      parts = [];
      for (var i = 0; i < n; i++) parts.push(spawn(true));
    }
    function wing() { return W < 900 ? { cx: -9999, cy: -9999, c: 1 } : { cx: W * 0.76, cy: H * 0.3, c: Math.min(W * 0.3, 480) }; }
    function spawn(anywhere) { return { x: anywhere ? Math.random() * W : -20, y: Math.random() * H, hist: [], sp: 0.6 + Math.random() * 0.8, hue: Math.random() }; }
    // Potential flow past an ellipse plus circulation: faster over the top, upwash ahead, downwash behind.
    function field(x, y) {
      var w = wing(), a = w.c * 0.5, b = w.c * 0.085;
      var X = (x - w.cx) / a, Y = (y - w.cy) / b;
      var r2 = Math.max(X * X + Y * Y, 1), r4 = r2 * r2;
      var us = 1 - (X * X - Y * Y) / r4, vs = -2 * X * Y / r4, G = 0.8;
      us += -G * Y / r2; vs += G * X / r2;
      return [us, vs * (b / a) * 2.2];
    }
    function drawWing(w) {
      hctx.save();
      hctx.translate(w.cx - w.c * 0.5, w.cy); hctx.rotate(-0.07); hctx.beginPath();
      var t = 0.12, c = w.c, i, xx, yt, yc;
      for (i = 0; i <= 60; i++) { xx = 1 - i / 60; yt = 5 * t * (0.2969 * Math.sqrt(xx) - 0.126 * xx - 0.3516 * xx * xx + 0.2843 * xx * xx * xx - 0.1036 * xx * xx * xx * xx); yc = xx < 0.4 ? 0.125 * (0.8 * xx - xx * xx) : 0.02 / 0.36 * (0.2 + 0.8 * xx - xx * xx); hctx.lineTo(xx * c, -(yc + yt) * c); }
      for (i = 0; i <= 60; i++) { xx = i / 60; yt = 5 * t * (0.2969 * Math.sqrt(xx) - 0.126 * xx - 0.3516 * xx * xx + 0.2843 * xx * xx * xx - 0.1036 * xx * xx * xx * xx); yc = xx < 0.4 ? 0.125 * (0.8 * xx - xx * xx) : 0.02 / 0.36 * (0.2 + 0.8 * xx - xx * xx); hctx.lineTo(xx * c, -(yc - yt) * c); }
      hctx.closePath();
      var g = hctx.createLinearGradient(0, -c * 0.1, 0, c * 0.08); g.addColorStop(0, "#22304f"); g.addColorStop(1, "#111a2c");
      hctx.fillStyle = g; hctx.fill(); hctx.strokeStyle = "rgba(255,200,61,.55)"; hctx.lineWidth = 1.2; hctx.stroke();
      hctx.restore();
    }
    function step(P) { var fv = field(P.x, P.y); P.x += fv[0] * 2.2 * P.sp; P.y += fv[1] * 2.2 * P.sp; P.hist.push(P.x, P.y); if (P.hist.length > 36) P.hist.splice(0, 2); return fv; }
    function draw() {
      hctx.clearRect(0, 0, W, H);
      var w = wing(); drawWing(w);
      for (var p = 0; p < parts.length; p++) {
        var P = parts[p], fv = step(P);
        var ex = (P.x - w.cx) / (w.c * 0.5), ey = (P.y - w.cy) / (w.c * 0.08);
        if (P.x > W + 30 || P.y < -30 || P.y > H + 30 || ex * ex + ey * ey < 1) { parts[p] = spawn(false); continue; }
        if (P.hist.length < 4) continue;
        hctx.beginPath(); hctx.moveTo(P.hist[0], P.hist[1]);
        for (var q = 2; q < P.hist.length; q += 2) hctx.lineTo(P.hist[q], P.hist[q + 1]);
        var speed = Math.hypot(fv[0], fv[1]);
        hctx.strokeStyle = P.hue > 0.82 ? "rgba(230,57,70,.55)" : speed > 1.15 ? "rgba(255,200,61,.6)" : "rgba(255,200,61,.3)";
        hctx.lineWidth = 1; hctx.stroke();
      }
      if (!reduce) requestAnimationFrame(draw);
    }
    function prewarm() { for (var s = 0; s < 18; s++) parts.forEach(step); }
    window.addEventListener("resize", function () { resize(); prewarm(); });
    resize(); prewarm(); draw();
  }
})();

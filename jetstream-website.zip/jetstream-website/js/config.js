/* =========================================================
   JetStream site settings: edit this file, nothing else needed.
   ========================================================= */
window.JETSTREAM_CONFIG = {
  clubName: "JetStream",
  school: "Heritage",

  // Club leaders (shown on About Us, Members and Home).
  // Add a photo by putting e.g. "assets/team/nivesh.jpg" in `photo`.
  leaders: [
    { name: "Nivesh Eshan Ahluwalia", role: "Club Leader", photo: "" },
    { name: "Arjun Singh Brar", role: "Club Leader", photo: "" },
    { name: "Parampreet Singh", role: "Club Leader", photo: "" }
  ],

  // Social media: paste your profile URLs. Empty ones are hidden.
  social: {
    instagram: "",
    youtube: "",
    linkedin: "",
    x: "",
    email: ""        // e.g. "jetstream@yourschool.org"
  },

  // ---------------------------------------------------------
  // Accounts backend
  //   "local"    : preview mode. Accounts live only in this browser (for testing).
  //   "firebase" : real shared accounts for the live site (free). See README.
  // ---------------------------------------------------------
  backend: "local",

  // Used only in "local" preview mode: a ready-made admin login for testing.
  localDemoAdmin: { name: "JetStream Admin", email: "admin@jetstream.local", password: "jetstream123" },

  // Fill in from Firebase console → Project settings → Your apps → Web app.
  firebase: {
    apiKey: "",
    authDomain: "",
    projectId: "",
    appId: ""
  }
};

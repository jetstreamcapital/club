/* =========================================================
   JetStream page logic (runs after config.js, store.js, main.js)
   ========================================================= */
(function () {
  "use strict";
  var Store = window.JetStore, CFG = window.JETSTREAM_CONFIG || {};
  var esc = Store.esc, $ = function (id) { return document.getElementById(id); };
  var page = document.body.getAttribute("data-page");
  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  function status(el, msg, ok) { if (!el) return; el.className = "form-status " + (ok ? "ok" : "err"); el.textContent = msg; }
  function paras(text) { return String(text || "").split(/\n\s*\n/).map(function (p) { return "<p>" + esc(p.trim()).replace(/\n/g, "<br>") + "</p>"; }).join(""); }
  function fmtDate(iso) { if (!iso) return "Date TBA"; var d = new Date(iso + (iso.length === 10 ? "T00:00:00" : "")); return isNaN(d) ? iso : d.getDate() + " " + MONTHS[d.getMonth()] + " " + d.getFullYear(); }
  function today() { var d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  function modeBanner(el) {
    if (!el || Store.mode !== "local") return;
    var a = CFG.localDemoAdmin || {};
    el.innerHTML = '<div class="banner"><b>Preview mode:</b> accounts are saved only in this browser on this computer. ' +
      "They become real, shared accounts once the site is connected to Firebase (see README)." +
      (page === "login" && a.email ? "<br>Test admin login: <b>" + esc(a.email) + "</b> / <b>" + esc(a.password) + "</b>" : "") + "</div>";
  }
  function formData(form) {
    var o = {}; new FormData(form).forEach(function (v, k) { if (o[k] !== undefined) { o[k] = [].concat(o[k], v); } else o[k] = v; }); return o;
  }

  // ---------------------------------------------------------------- Curriculum
  if (page === "curriculum") {
    var DATA = window.JETSTREAM_CURRICULUM || [];
    var tabs = $("level-tabs"), panels = $("level-panels");
    tabs.innerHTML = DATA.map(function (L, i) {
      return '<button class="level-tab" role="tab" id="tab-' + L.id + '" aria-controls="panel-' + L.id + '" aria-selected="' + (i === 0) + '" style="--c:' + L.color + '" data-id="' + L.id + '"><b>' + esc(L.level) + "</b><small>" + L.topics.length + " topics</small></button>";
    }).join("");
    panels.innerHTML = DATA.map(function (L, i) {
      return '<section class="level-panel" role="tabpanel" id="panel-' + L.id + '" aria-labelledby="tab-' + L.id + '"' + (i ? " hidden" : "") + ' style="--c:' + L.color + ';padding:0">' +
        '<div class="level-head"><span class="level-badge">Level ' + (i + 1) + " · " + esc(L.level) + "</span></div>" +
        '<h2 style="margin-top:10px">' + esc(L.title) + '</h2><p class="lead">' + esc(L.summary) + "</p>" +
        '<div class="topics">' + L.topics.map(function (t, k) {
          return '<article class="card topic"><h3><span class="k">' + String(k + 1).padStart(2, "0") + "</span>" + esc(t.t) + "</h3>" +
            (t.def ? '<div class="def"><b>Definition:</b> ' + esc(t.def) + "</div>" : "") +
            (t.p ? '<p style="margin-top:10px">' + esc(t.p) + "</p>" : "") +
            (t.try ? '<a class="try" href="' + t.try[0] + '">' + esc(t.try[1]) + " &rarr;</a>" : "") + "</article>";
        }).join("") + "</div></section>";
    }).join("");
    function show(id) {
      DATA.forEach(function (L) {
        $("tab-" + L.id).setAttribute("aria-selected", L.id === id ? "true" : "false");
        $("panel-" + L.id).hidden = L.id !== id;
      });
    }
    tabs.addEventListener("click", function (e) { var b = e.target.closest(".level-tab"); if (b) { show(b.dataset.id); history.replaceState(null, "", "#" + b.dataset.id); } });
    var h = location.hash.replace("#", "");
    if (DATA.some(function (L) { return L.id === h; })) { show(h); setTimeout(function () { $("levels").scrollIntoView(); }, 30); }
  }

  // ---------------------------------------------------------------- Join (sign up)
  if (page === "join") {
    modeBanner($("mode-banner"));
    var jf = $("join-form"), js = $("form-status");
    Store.ready.then(function () {
      var u = Store.user();
      if (u) status(js, "You're signed in as " + u.name + ". Welcome aboard!", true);
    });
    jf.addEventListener("submit", function (e) {
      e.preventDefault();
      var d = formData(jf);
      if (d.password !== d.password2) { status(js, "Passwords don't match."); return; }
      var btn = jf.querySelector("button[type=submit]"); btn.disabled = true;
      Store.signUp({ name: d.name, email: d.email, password: d.password, grade: d.grade, interests: [].concat(d.interest || []), showPublic: !!d.showPublic })
        .then(function (u) { status(js, "Welcome to JetStream, " + u.name + "! Your account is ready.", true); jf.reset(); })
        .catch(function (err) { status(js, err.message); })
        .then(function () { btn.disabled = false; });
    });
  }

  // ---------------------------------------------------------------- Login
  if (page === "login") {
    modeBanner($("mode-banner"));
    var lf = $("login-form"), ls = $("form-status");
    lf.addEventListener("submit", function (e) {
      e.preventDefault();
      var d = formData(lf);
      Store.signIn(d.email, d.password).then(function (u) {
        status(ls, "Signed in. Welcome back, " + u.name + "!", true);
        setTimeout(function () { location.href = u.isAdmin ? "admin.html" : "members.html"; }, 600);
      }).catch(function (err) { status(ls, err.message); });
    });
  }

  // ---------------------------------------------------------------- Members directory
  if (page === "members") {
    Store.listDirectory().then(function (list) {
      var el = $("member-dir");
      $("member-count").textContent = list.length;
      if (!list.length) { el.innerHTML = '<div class="empty-state" style="grid-column:1/-1">No members listed yet. <a href="join.html">Be the first to join!</a></div>'; return; }
      el.innerHTML = list.map(function (m) {
        return '<div class="card member"><div class="avatar sm">' + esc(Store.initials(m.name)) + "</div><div><b>" + esc(m.name) + "</b><span>" +
          (m.role === "admin" ? "Admin" : "Member") + (m.grade ? " · " + esc(m.grade) : "") + "</span></div></div>";
      }).join("");
    });
  }

  // ---------------------------------------------------------------- Lectures
  function lectureHTML(l) {
    var d = l.date ? new Date(l.date + "T00:00:00") : null;
    var box = d && !isNaN(d)
      ? '<div class="datebox"><div class="m">' + MONTHS[d.getMonth()] + '</div><div class="d">' + d.getDate() + '</div><div class="y">' + d.getFullYear() + "</div></div>"
      : '<div class="datebox"><div class="m">Date</div><div class="d">TBA</div></div>';
    return '<article class="card lecture">' + box + "<div><h3>" + esc(l.title) + (l.sample ? '<span class="sample-flag">Sample</span>' : "") + "</h3>" +
      '<div class="speaker">' + esc(l.speaker) + (l.affiliation ? ' <span class="muted" style="font-weight:400">· ' + esc(l.affiliation) + "</span>" : "") + "</div>" +
      '<div class="muted">' + paras(l.description) + "</div></div></article>";
  }
  if (page === "lectures") {
    Store.list("lectures").then(function (all) {
      var t = today();
      var up = all.filter(function (l) { return !l.date || l.date >= t; }).sort(function (a, b) { return (a.date || "9999").localeCompare(b.date || "9999"); });
      var past = all.filter(function (l) { return l.date && l.date < t; });
      $("upcoming").innerHTML = up.length ? up.map(lectureHTML).join("") : '<div class="empty-state">No guest lectures scheduled yet. Check back soon!</div>';
      $("past").innerHTML = past.length ? past.map(lectureHTML).join("") : '<div class="empty-state">Past lectures will be listed here.</div>';
    });
  }
  if (page === "home") {
    Store.list("lectures").then(function (all) {
      var t = today(), el = $("home-lectures");
      var up = all.filter(function (l) { return !l.date || l.date >= t; }).slice(0, 2);
      if (el) el.innerHTML = up.length ? up.map(lectureHTML).join("") : '<div class="empty-state">Guest lectures will be announced soon.</div>';
    });
  }

  // ---------------------------------------------------------------- Blog
  function postHTML(p) {
    return '<article class="card post"><h2 style="font-size:1.5rem">' + esc(p.title) + '</h2><div class="meta">' + esc(p.author || "JetStream") + " · " + fmtDate(p.date) + '</div><div class="body">' + paras(p.body) + "</div></article>";
  }
  if (page === "blog") {
    Store.list("posts").then(function (all) {
      $("posts").innerHTML = all.length ? all.map(postHTML).join("") : '<div class="empty-state">No posts yet.</div>';
    });
  }

  // ---------------------------------------------------------------- Admin
  if (page === "admin") {
    var gate = $("admin-gate"), app = $("admin-app");
    modeBanner($("mode-banner"));
    Store.ready.then(function () {
      var u = Store.user();
      if (!u) { gate.innerHTML = '<div class="empty-state">Please <a href="login.html">sign in</a> with an admin account to manage the club.</div>'; return; }
      if (!u.isAdmin) { gate.innerHTML = '<div class="empty-state">You are signed in as <b>' + esc(u.name) + "</b>, but this account is not an admin. Ask a club leader to give you admin access.</div>"; return; }
      gate.hidden = true; app.hidden = false;
      initAdmin(u);
    });
  }

  function initAdmin(me) {
    // Tabs
    var tabBtns = document.querySelectorAll("[data-admin-tab]");
    tabBtns.forEach(function (b) {
      b.addEventListener("click", function () {
        tabBtns.forEach(function (x) { x.setAttribute("aria-pressed", x === b ? "true" : "false"); });
        document.querySelectorAll("[data-admin-panel]").forEach(function (p) { p.hidden = p.getAttribute("data-admin-panel") !== b.getAttribute("data-admin-tab"); });
      });
    });

    // Members
    function loadMembers() {
      Store.listMembers().then(function (list) {
        $("m-count").textContent = list.length;
        $("m-rows").innerHTML = list.map(function (m) {
          var self = m.id === me.uid;
          return "<tr><td><b>" + esc(m.name) + "</b>" + (self ? ' <span class="pill-role">you</span>' : "") + "<br><span class=\"muted\" style=\"font-size:.84rem\">" + esc(m.email || "no email") + "</span></td>" +
            "<td>" + esc(m.grade || "") + "</td>" +
            '<td><select data-role="' + m.id + '"' + (self ? " disabled" : "") + '><option value="member"' + (m.role !== "admin" ? " selected" : "") + '>Member</option><option value="admin"' + (m.role === "admin" ? " selected" : "") + ">Admin</option></select></td>" +
            "<td>" + (m.showPublic ? "Yes" : "No") + "</td>" +
            "<td>" + (m.joined ? fmtDate(m.joined.slice(0, 10)) : "") + "</td>" +
            "<td>" + (self ? "" : '<button class="btn-del" data-del-member="' + m.id + '" data-name="' + esc(m.name) + '">Delete</button>') + "</td></tr>";
        }).join("") || '<tr><td colspan="6" class="muted">No members yet.</td></tr>';
      }).catch(function (e) { status($("m-status"), e.message); });
    }
    $("m-rows").addEventListener("change", function (e) {
      var s = e.target.closest("[data-role]"); if (!s) return;
      Store.setRole(s.getAttribute("data-role"), s.value).then(function () { status($("m-status"), "Role updated.", true); loadMembers(); }).catch(function (err) { status($("m-status"), err.message); loadMembers(); });
    });
    $("m-rows").addEventListener("click", function (e) {
      var b = e.target.closest("[data-del-member]"); if (!b) return;
      if (!confirm("Delete member " + b.getAttribute("data-name") + "? This cannot be undone.")) return;
      Store.deleteMember(b.getAttribute("data-del-member")).then(function () { status($("m-status"), "Member deleted.", true); loadMembers(); }).catch(function (err) { status($("m-status"), err.message); });
    });
    $("m-form").addEventListener("submit", function (e) {
      e.preventDefault(); var f = e.target, d = formData(f);
      Store.addMember({ name: d.name, email: d.email, grade: d.grade, role: d.role, showPublic: !!d.showPublic })
        .then(function () { status($("m-status"), "Member added.", true); f.reset(); loadMembers(); })
        .catch(function (err) { status($("m-status"), err.message); });
    });

    // Generic list manager for lectures & posts
    function manager(col, prefix, render) {
      function load() {
        Store.list(col).then(function (list) {
          $(prefix + "-list").innerHTML = list.length ? list.map(function (x) {
            return '<div class="card" style="padding:16px 18px;display:flex;justify-content:space-between;gap:14px;align-items:center;margin-bottom:10px"><div>' + render(x) + '</div><button class="btn-del" data-del="' + x.id + '" data-name="' + esc(x.title) + '">Delete</button></div>';
          }).join("") : '<div class="empty-state">Nothing here yet.</div>';
        });
      }
      $(prefix + "-list").addEventListener("click", function (e) {
        var b = e.target.closest("[data-del]"); if (!b) return;
        if (!confirm("Delete \"" + b.getAttribute("data-name") + "\"?")) return;
        Store.remove(col, b.getAttribute("data-del")).then(function () { status($(prefix + "-status"), "Deleted.", true); load(); }).catch(function (err) { status($(prefix + "-status"), err.message); });
      });
      $(prefix + "-form").addEventListener("submit", function (e) {
        e.preventDefault(); var f = e.target, d = formData(f);
        Store.add(col, d).then(function () { status($(prefix + "-status"), "Published.", true); f.reset(); load(); }).catch(function (err) { status($(prefix + "-status"), err.message); });
      });
      load();
    }
    manager("lectures", "l", function (l) { return "<b>" + esc(l.title) + "</b>" + (l.sample ? '<span class="sample-flag">Sample</span>' : "") + '<br><span class="muted" style="font-size:.86rem">' + esc(l.speaker) + " · " + fmtDate(l.date) + "</span>"; });
    manager("posts", "p", function (p) { return "<b>" + esc(p.title) + '</b><br><span class="muted" style="font-size:.86rem">' + esc(p.author || "") + " · " + fmtDate(p.date) + "</span>"; });
    var pd = document.querySelector("#p-form [name=date]"); if (pd) pd.value = today();
    loadMembers();
  }
})();

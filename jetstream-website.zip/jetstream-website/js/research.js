/* Jetstream Research Hub: bibliography data + filter/search.
   To add a text, append an object to BIB. Tracks: aero | drag | prop | space */
(function () {
  "use strict";

  var TRACKS = {
    aero: { label: "Aerodynamics & Flight Physics", cls: "c" },
    drag: { label: "Turbulence & Drag", cls: "v" },
    prop: { label: "Propulsion & Energy", cls: "o" },
    space: { label: "Satellite & Space", cls: "g" }
  };

  var BIB = [
    {
      track: "aero", author: "Anderson, J. D.", title: "Fundamentals of Aerodynamics", pub: "McGraw-Hill Education",
      focus: "Subsonic flow, lift generation mechanics, boundary layer theory, and compressible aerodynamics.",
      concepts: ["Lift", "Potential flow", "Boundary layers", "Compressibility"], level: 2
    },
    {
      track: "aero", author: "Federal Aviation Administration (FAA)", title: "Pilot's Handbook of Aeronautical Knowledge (PHAK)", pub: "FAA-H-8083-25B",
      focus: "Airplane control surfaces, pitch/yaw/roll stability, angle of attack (α), stall mechanics, and atmospheric conditions.",
      concepts: ["Control surfaces", "Stability", "Angle of attack", "Stall"], level: 1,
      link: "https://www.faa.gov/regulations_policies/handbooks_manuals/aviation/phak", linkLabel: "Free from the FAA"
    },
    {
      track: "aero", author: "NASA Glenn Research Center", title: "Beginner's Guide to Aerodynamics", pub: "NASA (online)",
      focus: "Interactive modules on the Bernoulli principle, Newton's third law in lift generation, and pressure distributions over NACA airfoils.",
      concepts: ["Bernoulli", "Newton's 3rd law", "NACA airfoils", "Pressure"], level: 1,
      link: "https://www.grc.nasa.gov/www/k-12/airplane/", linkLabel: "Open the guide"
    },
    {
      track: "drag", author: "Hoerner, S. F.", title: "Fluid-Dynamic Drag", pub: "Practical Information on Aerodynamic Drag and Hydrodynamic Resistance",
      focus: "Empirical data on form drag, skin friction drag, induced drag, and bluff body aerodynamics.",
      concepts: ["Form drag", "Skin friction", "Induced drag", "Bluff bodies"], level: 3
    },
    {
      track: "drag", author: "White, F. M.", title: "Fluid Mechanics", pub: "McGraw-Hill",
      focus: "Navier–Stokes equations, Reynolds number (Re) regimes, laminar vs. turbulent transition, and boundary layer separation.",
      concepts: ["Navier–Stokes", "Reynolds number", "Transition", "Separation"], level: 2
    },
    {
      track: "drag", author: "Schlichting, H., & Gersten, K.", title: "Boundary-Layer Theory", pub: "Springer",
      focus: "Viscous flows, wall turbulence, skin friction coefficient (Cf), and flow separation mitigation techniques.",
      concepts: ["Viscous flow", "Wall turbulence", "Skin friction Cf", "Flow control"], level: 3
    },
    {
      track: "prop", author: "Sutton, G. P., & Biblarz, O.", title: "Rocket Propulsion Elements", pub: "Wiley",
      focus: "Chemical rocket engines, specific impulse (Isp), nozzle thermodynamic expansion (CF), and thrust equations.",
      concepts: ["Specific impulse", "Nozzles", "Thrust coefficient", "Chemical rockets"], level: 2
    },
    {
      track: "space", author: "Cal Poly CubeSat Program Office", title: "CubeSat Design Specification (CDS)", pub: "Cal Poly San Luis Obispo",
      focus: "Standardized 1U to 3U nanosatellite mechanical interfaces, structural vibration resistance, and payload integration.",
      concepts: ["1U–3U form factor", "Deployers", "Vibration", "Payloads"], level: 2,
      link: "https://www.cubesat.org/", linkLabel: "cubesat.org"
    },
    {
      track: "prop", author: "ICAO", title: "Sustainable Aviation Fuels (SAF) & Environmental Protection Reports", pub: "International Civil Aviation Organization",
      focus: "Biofuels, hydrogen-electric fuel cell powertrains, and lifecycle emissions reduction in commercial aviation.",
      concepts: ["SAF", "Hydrogen-electric", "Fuel cells", "Lifecycle emissions"], level: 1,
      link: "https://www.icao.int/environmental-protection", linkLabel: "ICAO Environment"
    }
  ];

  var LEVELS = ["", "Introductory", "Intermediate", "Advanced"];
  var grid = document.getElementById("bib-grid");
  var empty = document.getElementById("bib-empty");
  var search = document.getElementById("bib-search");
  var chips = document.querySelectorAll("[data-filter]");
  var state = { track: "all", q: "" };

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  function card(b) {
    var t = TRACKS[b.track];
    var dots = "";
    for (var i = 1; i <= 3; i++) dots += '<i class="' + (i <= b.level ? "on" : "") + '"></i>';
    return (
      '<article class="card bib">' +
      '<div class="tags"><span class="tag ' + t.cls + '">' + esc(t.label) + "</span>" + (b.link ? '<span class="tag g">Free access</span>' : "") + "</div>" +
      '<div><div class="author">' + esc(b.author) + "</div><h3>" + esc(b.title) + '</h3><div class="pub">' + esc(b.pub) + "</div></div>" +
      '<p class="focus"><b style="color:var(--text)">Focus:</b> ' + esc(b.focus) + "</p>" +
      '<div class="tags">' + b.concepts.map(function (c) { return '<span class="tag">' + esc(c) + "</span>"; }).join("") + "</div>" +
      '<div class="foot"><span class="level">' + dots + " " + LEVELS[b.level] + "</span>" +
      (b.link ? '<a href="' + b.link + '" target="_blank" rel="noopener">' + esc(b.linkLabel) + " &#8599;</a>" : '<span class="level">Library / textbook</span>') +
      "</div></article>"
    );
  }

  function render() {
    var q = state.q.toLowerCase();
    var list = BIB.filter(function (b) {
      if (state.track !== "all" && b.track !== state.track) return false;
      if (!q) return true;
      return (b.title + " " + b.author + " " + b.focus + " " + b.concepts.join(" ") + " " + b.pub).toLowerCase().indexOf(q) !== -1;
    });
    grid.innerHTML = list.map(card).join("");
    empty.style.display = list.length ? "none" : "block";
  }

  function setTrack(t) {
    state.track = t;
    chips.forEach(function (c) { c.setAttribute("aria-pressed", c.getAttribute("data-filter") === t ? "true" : "false"); });
    render();
  }

  chips.forEach(function (c) { c.addEventListener("click", function () { setTrack(c.getAttribute("data-filter")); }); });
  search.addEventListener("input", function () { state.q = search.value.trim(); render(); });
  document.querySelectorAll("[data-jump]").forEach(function (b) {
    b.addEventListener("click", function () {
      setTrack(b.getAttribute("data-jump"));
      document.getElementById("library").scrollIntoView({ behavior: "smooth" });
    });
  });

  var hash = location.hash.replace("#", "");
  if (TRACKS[hash]) {
    setTrack(hash);
    setTimeout(function () { document.getElementById("library").scrollIntoView(); }, 50);
  } else render();
})();

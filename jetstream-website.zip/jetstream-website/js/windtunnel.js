/* =========================================================
   JetStream Web Wind Tunnel
   ---------------------------------------------------------
   Physics:  ISA atmosphere, Sutherland viscosity, Reynolds
             number, empirical C_D / C_L models per geometry,
             lifting-line induced drag, Strouhal shedding.
   Flow viz: potential-flow stream function ψ solved with SOR
             on a 200×112 grid (∇²ψ = 0, ψ = const on body,
             body ψ offset sets circulation ∝ C_L), plus a
             kinematic separated wake / Kármán vortex street.
   ========================================================= */
(function () {
  "use strict";

  // ------------------------------------------------------------------
  // Domain (world units: 1 = characteristic length L of the body)
  // ------------------------------------------------------------------
  const X0 = -1.15, X1 = 2.85, Y0 = -1.12, Y1 = 1.12;
  const NX = 200, NY = 112;
  const DX = (X1 - X0) / (NX - 1), DY = (Y1 - Y0) / (NY - 1);
  const RD = 287.05, D2R = Math.PI / 180, PI = Math.PI;

  const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);
  const lerp = (a, b, t) => a + (b - a) * t;
  const smooth = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
  const sigm = (x) => 1 / (1 + Math.exp(-x));
  const $ = (id) => document.getElementById(id);

  const SHAPES = {
    naca0012: { name: "NACA 0012", kind: "airfoil", m: 0, p: 0.4, t: 0.12, aL0: 0, clmax: 1.5, pivot: 0.25, Llabel: "Chord c" },
    naca4412: { name: "NACA 4412", kind: "airfoil", m: 0.04, p: 0.4, t: 0.12, aL0: -4, clmax: 1.65, pivot: 0.25, Llabel: "Chord c" },
    plate: { name: "Flat plate", kind: "plate", Llabel: "Plate side L" },
    cylinder: { name: "Cylinder", kind: "cylinder", Llabel: "Diameter D" },
    sphere: { name: "Sphere", kind: "sphere", Llabel: "Diameter D" },
    teardrop: { name: "Teardrop", kind: "teardrop", t: 0.3, pivot: 0.35, Llabel: "Body length l" }
  };

  const DEFAULT = { shape: "naca4412", v: 30, alt: 0, aoa: 4, L: 0.3, b: 1.5, e: 0.85 };
  const state = Object.assign({}, DEFAULT, { paused: false });

  // ------------------------------------------------------------------
  // Geometry
  // ------------------------------------------------------------------
  function nacaPoints(m, p, t, n) {
    const up = [], lo = [];
    for (let i = 0; i <= n; i++) {
      const x = 0.5 * (1 - Math.cos((PI * i) / n));
      const yt = 5 * t * (0.2969 * Math.sqrt(x) - 0.126 * x - 0.3516 * x * x + 0.2843 * x * x * x - 0.1036 * x * x * x * x);
      let yc = 0, dyc = 0;
      if (m > 0) {
        if (x < p) { yc = (m / (p * p)) * (2 * p * x - x * x); dyc = ((2 * m) / (p * p)) * (p - x); }
        else { yc = (m / ((1 - p) * (1 - p))) * (1 - 2 * p + 2 * p * x - x * x); dyc = ((2 * m) / ((1 - p) * (1 - p))) * (p - x); }
      }
      const th = Math.atan(dyc);
      up.push([x - yt * Math.sin(th), yc + yt * Math.cos(th)]);
      lo.push([x + yt * Math.sin(th), yc - yt * Math.cos(th)]);
    }
    const pts = [];
    for (let i = n; i >= 0; i--) pts.push(up[i]);
    for (let i = 1; i < n; i++) pts.push(lo[i]);
    return pts;
  }

  function signedArea(pts) {
    let a = 0;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) a += pts[j][0] * pts[i][1] - pts[i][0] * pts[j][1];
    return a / 2;
  }

  function buildBody(shapeKey, aoaDeg) {
    const s = SHAPES[shapeKey];
    let pts, te = null, ac = [0, 0];
    if (s.kind === "airfoil" || s.kind === "teardrop") {
      pts = nacaPoints(s.m || 0, s.p || 0.4, s.t, 90).map((q) => [q[0] - s.pivot, q[1]]);
      te = [1 - s.pivot, 0];
    } else if (s.kind === "plate") {
      const w = 0.03, h = 0.5;
      pts = [[-w, -h], [w, -h], [w, h], [-w, h]];
    } else {
      pts = [];
      for (let i = 0; i < 96; i++) { const a = (2 * PI * i) / 96; pts.push([0.5 * Math.cos(a), 0.5 * Math.sin(a)]); }
    }
    const symmetric = s.kind === "cylinder" || s.kind === "sphere";
    // Bluff bodies are drawn smaller than airfoils so the tunnel walls don't choke the flow (blockage).
    const scale = symmetric ? 0.56 : s.kind === "plate" ? 0.62 : 1;
    const th = symmetric ? 0 : -aoaDeg * D2R; // nose-up = clockwise in y-up frame
    const c = Math.cos(th), sn = Math.sin(th);
    const rot = (q) => [(q[0] * c - q[1] * sn) * scale, (q[0] * sn + q[1] * c) * scale];
    pts = pts.map(rot);
    if (te) te = rot(te);
    if (signedArea(pts) < 0) pts.reverse();

    let xmin = 1e9, xmax = -1e9, ymin = 1e9, ymax = -1e9, cx = 0, cy = 0;
    pts.forEach((q) => {
      xmin = Math.min(xmin, q[0]); xmax = Math.max(xmax, q[0]);
      ymin = Math.min(ymin, q[1]); ymax = Math.max(ymax, q[1]);
      cx += q[0]; cy += q[1];
    });
    cx /= pts.length; cy /= pts.length;
    if (s.kind !== "airfoil") ac = [cx, cy];

    // Evenly spaced perimeter samples with outward normals (for surface C_p arrows)
    const segs = []; let per = 0;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      segs.push({ a, b, len, s0: per }); per += len;
    }
    const NS = s.kind === "plate" ? 30 : 34, samples = [];
    for (let k = 0; k < NS; k++) {
      const target = ((k + 0.5) / NS) * per;
      const sg = segs.find((g) => target >= g.s0 && target <= g.s0 + g.len) || segs[segs.length - 1];
      const t = sg.len ? (target - sg.s0) / sg.len : 0;
      const ex = (sg.b[0] - sg.a[0]) / (sg.len || 1), ey = (sg.b[1] - sg.a[1]) / (sg.len || 1);
      samples.push({ x: lerp(sg.a[0], sg.b[0], t), y: lerp(sg.a[1], sg.b[1], t), nx: ey, ny: -ex });
    }
    return { pts, te, ac, xmin, xmax, ymin, ymax, cx, cy, samples, kind: s.kind, scale };
  }

  function inside(pts, x, y) {
    let c = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const xi = pts[i][0], yi = pts[i][1], xj = pts[j][0], yj = pts[j][1];
      if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c;
    }
    return c;
  }
  function distToPoly(pts, x, y) {
    let d = 1e9;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const ax = pts[j][0], ay = pts[j][1], bx = pts[i][0], by = pts[i][1];
      const vx = bx - ax, vy = by - ay, l2 = vx * vx + vy * vy || 1e-12;
      const t = clamp(((x - ax) * vx + (y - ay) * vy) / l2, 0, 1);
      const dx = x - (ax + t * vx), dy = y - (ay + t * vy);
      d = Math.min(d, dx * dx + dy * dy);
    }
    return Math.sqrt(d);
  }

  // ------------------------------------------------------------------
  // Stream-function solver
  // ------------------------------------------------------------------
  const psi = new Float32Array(NX * NY);
  const mask = new Uint8Array(NX * NY);
  const GU = new Float32Array(NX * NY), GV = new Float32Array(NX * NY);
  let psiB = 0;

  function buildMask(body) {
    mask.fill(0);
    const pad = 0.55 * Math.max(DX, DY);
    for (let j = 0; j < NY; j++) {
      const y = Y0 + j * DY;
      if (y < body.ymin - pad || y > body.ymax + pad) continue;
      for (let i = 0; i < NX; i++) {
        const x = X0 + i * DX;
        if (x < body.xmin - pad || x > body.xmax + pad) continue;
        if (inside(body.pts, x, y) || distToPoly(body.pts, x, y) < pad) mask[j * NX + i] = 1;
      }
    }
  }

  function solve(iters, cold) {
    if (cold) for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) psi[j * NX + i] = Y0 + j * DY;
    for (let k = 0; k < NX * NY; k++) if (mask[k]) psi[k] = psiB;
    const cx = 1 / (DX * DX), cy = 1 / (DY * DY), den = 1 / (2 * cx + 2 * cy), w = 1.93;
    for (let it = 0; it < iters; it++) {
      for (let j = 1; j < NY - 1; j++) {
        let k = j * NX + 1;
        for (let i = 1; i < NX - 1; i++, k++) {
          if (mask[k]) continue;
          const g = ((psi[k - 1] + psi[k + 1]) * cx + (psi[k - NX] + psi[k + NX]) * cy) * den;
          psi[k] += w * (g - psi[k]);
        }
      }
    }
    for (let j = 0; j < NY; j++) {
      for (let i = 0; i < NX; i++) {
        const k = j * NX + i;
        if (i === 0 || j === 0 || i === NX - 1 || j === NY - 1) { GU[k] = 1; GV[k] = 0; continue; }
        if (mask[k]) { GU[k] = 0; GV[k] = 0; continue; }
        GU[k] = (psi[k + NX] - psi[k - NX]) / (2 * DY);
        GV[k] = -(psi[k + 1] - psi[k - 1]) / (2 * DX);
      }
    }
  }

  function solidAt(x, y) {
    const i = Math.round((x - X0) / DX), j = Math.round((y - Y0) / DY);
    if (i < 0 || j < 0 || i >= NX || j >= NY) return false;
    return mask[j * NX + i] === 1;
  }

  // ------------------------------------------------------------------
  // Physics
  // ------------------------------------------------------------------
  function atmosphere(h) {
    const T = 288.15 - 0.0065 * h;
    const P = 101325 * Math.pow(T / 288.15, 5.25588);
    return { T, P, rho: P / (RD * T), mu: (1.458e-6 * Math.pow(T, 1.5)) / (T + 110.4) };
  }
  function skinFriction(Re) {
    Re = Math.max(Re, 50);
    return Re < 5e5 ? 1.328 / Math.sqrt(Re) : 0.074 / Math.pow(Re, 0.2) - 1742 / Re;
  }
  const lg = (x) => Math.log10(Math.max(x, 1e-9));
  function logBlend(Re, r0, r1, c0, c1) { return lerp(c0, c1, smooth(lg(r0), lg(r1), lg(Re))); }

  function cdCylinder(Re) {
    Re = Math.max(Re, 0.05);
    if (Re < 2e5) return 1 + 10 / Math.pow(Re, 2 / 3);
    if (Re < 5e5) return logBlend(Re, 2e5, 5e5, 1 + 10 / Math.pow(2e5, 2 / 3), 0.3);
    if (Re < 4e6) return logBlend(Re, 5e5, 4e6, 0.3, 0.7);
    return 0.7;
  }
  function cdSphere(Re) {
    Re = Math.max(Re, 0.05);
    const white = (r) => 24 / r + 6 / (1 + Math.sqrt(r)) + 0.4;
    if (Re < 2e5) return white(Re);
    if (Re < 4e5) return logBlend(Re, 2e5, 4e5, white(2e5), 0.1);
    if (Re < 1e6) return logBlend(Re, 4e5, 1e6, 0.1, 0.2);
    return 0.2;
  }

  function computePhysics(st) {
    const s = SHAPES[st.shape];
    const atm = atmosphere(st.alt);
    const v = st.v, L = st.L;
    const Re = (atm.rho * v * L) / atm.mu;
    const ReE = Math.max(Re, 0.01); // evaluate coefficients even at v → 0
    const lr = lg(ReE);
    const q = 0.5 * atm.rho * v * v;
    const a = s.kind === "cylinder" || s.kind === "sphere" ? 0 : st.aoa * D2R;
    const r = { atm, Re, q, CL: 0, CD: 0, CDi: 0, A: 0, AR: null, stall: 0, sep: 0, shed: 0, jit: 0, crisis: false, areaNote: "", lifting: false, note: "" };

    if (s.kind === "airfoil") {
      const c = L, b = st.b, S = c * b, AR = b / c, e = st.e;
      const reF = clamp((lr - 4) / (6.3 - 4), 0, 1);
      const clmax2d = s.clmax * (0.55 + 0.45 * reF);
      const a0 = 2 * PI * 0.95 * (0.75 + 0.25 * reF);
      const a3 = a0 / (1 + a0 / (PI * e * AR));
      const ae = a - s.aL0 * D2R;
      const CLmax = 0.88 * clmax2d, CLmin = -0.88 * clmax2d * (s.m > 0 ? 0.72 : 1);
      const aSp = CLmax / a3, aSn = CLmin / a3, dS = 1.6 * D2R;
      const sig = ae >= 0 ? sigm((ae - aSp) / dS) : sigm((aSn - ae) / dS);
      const CLatt = clamp(a3 * ae, CLmin, CLmax);
      const CLfp = 0.9 * Math.sin(2 * a);
      const CL = (1 - sig) * CLatt + sig * CLfp;
      const cf = skinFriction(ReE);
      let Cd0 = 2 * cf * (1 + 2 * s.t + 60 * Math.pow(s.t, 4));
      Cd0 *= 1 + 1.5 * Math.pow(1 - reF, 2); // laminar-bubble penalty at low Re
      const Cdp = Cd0 * (1 + 0.55 * CLatt * CLatt);
      const Cdfp = 1.9 * Math.sin(a) * Math.sin(a) + Cd0;
      const CDi = (CL * CL) / (PI * AR * e);
      r.CL = CL; r.CDi = CDi; r.CD = (1 - sig) * Cdp + sig * Cdfp + CDi;
      r.A = S; r.AR = AR; r.stall = sig; r.lifting = true;
      r.areaNote = "planform S = b·c";
      r.sep = sig;
      r.shed = sig * smooth(3, 4, lr);
      r.jit = smooth(3.36, 5, lr) * (0.15 + 0.85 * sig);
      r.note = sig > 0.5 ? "stalled" : "attached flow";
    } else if (s.kind === "cylinder") {
      r.CD = cdCylinder(ReE); r.A = L * st.b; r.areaNote = "frontal D·b";
      r.sep = smooth(lg(4), lg(40), lr);
      r.shed = smooth(lg(40), lg(80), lr);
      r.jit = smooth(3.36, 5, lr);
      r.crisis = Re > 2.6e5;
      r.note = "symmetric: no lift";
    } else if (s.kind === "sphere") {
      r.CD = cdSphere(ReE); r.A = (PI * L * L) / 4; r.areaNote = "frontal πD²/4";
      r.sep = smooth(lg(20), lg(130), lr);
      r.shed = smooth(lg(200), lg(450), lr);
      r.jit = smooth(3.36, 5, lr);
      r.crisis = Re > 2.6e5;
      r.note = "symmetric: no lift";
    } else if (s.kind === "plate") {
      const Cn = 1.17 + 64 / (PI * ReE);
      r.CD = Cn * Math.cos(a); r.CL = -Cn * Math.sin(a);
      r.A = L * L; r.areaNote = "plate area L²"; r.lifting = Math.abs(a) > 0.001;
      r.sep = smooth(0, 1, lr);
      r.shed = smooth(1.4, 1.9, lr);
      r.jit = smooth(3.36, 5, lr);
      r.note = Math.abs(a) > 0.001 ? "normal force tilts with α" : "pure pressure drag";
    } else if (s.kind === "teardrop") {
      const dl = s.t, cf = skinFriction(ReE);
      const Cd0 = cf * (3 / dl + 4.5 * Math.sqrt(dl) + 21 * dl * dl);
      const sa = Math.sin(a);
      const CL = Math.sin(2 * a) * Math.cos(a / 2) + 3.6 * sa * Math.abs(sa) * Math.cos(a);
      r.CL = CL; r.CD = Cd0 + 3.6 * Math.abs(sa * sa * sa) + 0.5 * Math.abs(CL * sa);
      r.A = PI * Math.pow(dl * L, 2) / 4; r.areaNote = "frontal π(0.3l)²/4"; r.lifting = Math.abs(a) > 0.001;
      const sepA = smooth(4 * D2R, 18 * D2R, Math.abs(a));
      r.stall = sepA; r.sep = 0.05 + 0.6 * sepA;
      r.shed = sepA * smooth(3, 4, lr);
      r.jit = smooth(3.36, 5, lr) * (0.2 + 0.8 * sepA);
      r.note = "streamlined body";
    }

    r.FD = q * r.A * r.CD;
    r.FL = q * r.A * r.CL;
    r.P = r.FD * v;
    r.LD = Math.abs(r.CD) > 1e-9 ? r.CL / r.CD : 0;
    r.regime = Re < 2.3e3 ? "lam" : Re <= 1e5 ? "tr" : "tu";
    return r;
  }

  // ------------------------------------------------------------------
  // Wake model (kinematic separated region + Kármán street)
  // ------------------------------------------------------------------
  const W = { s: 0, xs: 0, yw: 0, h0: 0.5, grow: 0.12, decay: 2, recirc: 0, shed: 0, jit: 0, kw: 1, cpb: -0.5 };

  function updateWake(body, ph) {
    const H = body.ymax - body.ymin;
    if (body.kind === "airfoil" || body.kind === "teardrop") {
      const sg = ph.stall;
      const upper = state.aoa >= 0;
      const xsS = body.xmin + 0.22 * (body.xmax - body.xmin);
      const ywS = upper ? (body.ymax + body.te[1]) / 2 : (body.ymin + body.te[1]) / 2;
      const h0S = Math.abs((upper ? body.ymax : body.ymin) - body.te[1]) / 2 + 0.07;
      W.xs = lerp(body.te[0] - 0.02, xsS, sg);
      W.yw = lerp(body.te[1], ywS, sg);
      W.h0 = lerp(0.035 + 0.12 * H, h0S, sg);
      W.s = body.kind === "airfoil" ? 0.12 + 0.88 * sg : 0.1 + 0.6 * sg;
      W.recirc = 0.4 * sg; W.decay = 1.6;
    } else {
      const crisis = ph.crisis && body.kind !== "plate";
      W.xs = body.cx + (crisis ? 0.12 : -0.02);
      W.yw = body.cy;
      W.h0 = 0.5 * H * (crisis ? 0.72 : 1.08);
      W.s = ph.sep;
      W.recirc = 0.45 * ph.sep; W.decay = 2.2;
    }
    W.shed = ph.shed; W.jit = ph.jit;
    W.kw = (2 * PI * 0.2) / (2 * W.h0); // Strouhal 0.2 based on wake width
    W.cpb = -clamp(0.9 * (ph.CD - ph.CDi), 0.03, 1.2);
  }

  const F = { ui: 0, vi: 0, u: 1, v: 0, w: 0, dx: 0 };
  function flowAt(x, y, tau, shed) {
    const fx = (x - X0) / DX, fy = (y - Y0) / DY;
    const i = Math.floor(fx), j = Math.floor(fy);
    if (i < 0 || j < 0 || i >= NX - 1 || j >= NY - 1) { F.ui = 1; F.vi = 0; }
    else {
      const tx = fx - i, ty = fy - j, k = j * NX + i;
      F.ui = (GU[k] * (1 - tx) + GU[k + 1] * tx) * (1 - ty) + (GU[k + NX] * (1 - tx) + GU[k + NX + 1] * tx) * ty;
      F.vi = (GV[k] * (1 - tx) + GV[k + 1] * tx) * (1 - ty) + (GV[k + NX] * (1 - tx) + GV[k + NX + 1] * tx) * ty;
    }
    let u = F.ui, v = F.vi;
    F.w = 0; F.dx = 0;
    if (W.s > 0.002 && x > W.xs) {
      const dxw = x - W.xs, hx = W.h0 * (1 + W.grow * dxw);
      const yy = (y - W.yw) / hx, y4 = yy * yy * yy * yy;
      if (y4 < 14) {
        const w = W.s * Math.exp(-y4) * (1 - Math.exp(-dxw / 0.06));
        const def = 0.85 * Math.exp(-dxw / W.decay) + W.recirc * Math.exp(-dxw / (0.8 * W.h0 + 0.08));
        u *= 1 - w * def;
        v *= 1 - w * 0.8 * Math.min(def, 1);
        if (shed && W.shed > 0.001) {
          const amp = W.shed * w * (1 - Math.exp(-dxw / (0.5 * W.h0 + 0.08))) * 0.5;
          const ph = W.kw * (0.85 * tau - dxw);
          v += amp * Math.sin(ph);
          u += amp * 0.6 * Math.cos(ph) * Math.tanh(2 * yy);
        }
        F.w = w; F.dx = dxw;
      }
    }
    F.u = u; F.v = v;
    return F;
  }
  function cpOf(f) {
    const cpi = 1 - (f.ui * f.ui + f.vi * f.vi);
    const wb = f.w * Math.exp(-f.dx / 2.2);
    return lerp(Math.max(cpi, -3), W.cpb, clamp(wb, 0, 1));
  }

  // ------------------------------------------------------------------
  // Rendering
  // ------------------------------------------------------------------
  const canvas = $("tunnel"), ctx = canvas.getContext("2d");
  const heat = document.createElement("canvas"); heat.width = NX; heat.height = NY;
  const hctx = heat.getContext("2d"), himg = hctx.createImageData(NX, NY);
  let Wpx = 0, Hpx = 0, S = 1, dpr = 1;
  const sx = (x) => (x - X0) * S, sy = (y) => (Y1 - y) * S;

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = canvas.clientWidth || 800;
    Wpx = Math.round(w * dpr);
    Hpx = Math.round((w * dpr * (Y1 - Y0)) / (X1 - X0));
    canvas.width = Wpx; canvas.height = Hpx;
    S = Wpx / (X1 - X0);
  }

  const BG = [4, 8, 17], HI = [255, 90, 90], LO = [61, 139, 255];
  function computeHeat() {
    const d = himg.data;
    for (let j = 0; j < NY; j++) {
      const y = Y0 + j * DY;
      for (let i = 0; i < NX; i++) {
        const k = j * NX + i, o = ((NY - 1 - j) * NX + i) * 4;
        let r = BG[0], g = BG[1], b = BG[2];
        if (!mask[k]) {
          const cp = cpOf(flowAt(X0 + i * DX, y, 0, false));
          if (cp >= 0) { const t = Math.pow(clamp(cp, 0, 1), 0.85) * 0.72; r = lerp(BG[0], HI[0], t); g = lerp(BG[1], HI[1], t); b = lerp(BG[2], HI[2], t); }
          else { const t = Math.pow(clamp(-cp / 1.6, 0, 1), 0.8) * 0.72; r = lerp(BG[0], LO[0], t); g = lerp(BG[1], LO[1], t); b = lerp(BG[2], LO[2], t); }
        }
        d[o] = r; d[o + 1] = g; d[o + 2] = b; d[o + 3] = 255;
      }
    }
    hctx.putImageData(himg, 0, 0);
  }

  // Particle colour buckets: C_p from −1.5 (blue) → 0 (pale) → +1 (red)
  const NB = 11, BUCKET = [];
  for (let b = 0; b < NB; b++) {
    const cp = lerp(-1.5, 1, b / (NB - 1));
    let c;
    if (cp < 0) { const t = clamp(-cp / 1.5, 0, 1); c = [lerp(205, 110, t), lerp(215, 170, t), 255]; }
    else { const t = clamp(cp, 0, 1); c = [255, lerp(215, 120, t), lerp(240, 110, t)]; }
    const rgb = (c[0] | 0) + "," + (c[1] | 0) + "," + (c[2] | 0);
    BUCKET.push(["rgba(" + rgb + ",0.18)", "rgba(" + rgb + ",0.45)", "rgba(" + rgb + ",0.9)"]);
  }
  const bucketOf = (cp) => clamp(Math.round(((cp + 1.5) / 2.5) * (NB - 1)), 0, NB - 1);

  // Particles
  const TRAIL = 26;
  let parts = [];
  function makeParticle(anywhere) {
    const p = { x: 0, y: 0, hx: new Float32Array(TRAIL), hy: new Float32Array(TRAIL), n: 0, age: 0, max: 0, b: 5 };
    resetParticle(p, anywhere);
    return p;
  }
  function resetParticle(p, anywhere) {
    let tries = 0;
    do {
      p.x = anywhere ? X0 + Math.random() * (X1 - X0) : X0 + Math.random() * 0.04;
      p.y = Y0 + 0.02 + Math.random() * (Y1 - Y0 - 0.04);
      tries++;
    } while (anywhere && tries < 20 && (solidAt(p.x, p.y) || inside(body.pts, p.x, p.y)));
    p.n = 0; p.age = 0;
    p.max = (2.6 * (X1 - X0)) / Math.max(visSpeed(), 0.004) * (0.6 + Math.random() * 0.8);
  }
  function initParticles() {
    const n = Math.round(clamp((canvas.clientWidth || 800) * 1.15, 450, 1000));
    parts = [];
    for (let i = 0; i < n; i++) parts.push(makeParticle(true));
  }
  function visSpeed() { return state.v <= 0 ? 0 : 0.006 + 0.02 * (state.v / 100); }

  let tau = 0;
  function stepParticles() {
    const h = visSpeed();
    if (h <= 0) return;
    tau += h;
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      let f = flowAt(p.x, p.y, tau, true);
      const mx = p.x + f.u * h * 0.5, my = p.y + f.v * h * 0.5;
      f = flowAt(mx, my, tau, true);
      p.x += f.u * h; p.y += f.v * h;
      if (W.jit > 0 && f.w > 0.02) {
        p.x += (Math.random() - 0.5) * W.jit * f.w * h * 0.9;
        p.y += (Math.random() - 0.5) * W.jit * f.w * h * 1.4;
      }
      p.age++;
      if (p.x > X1 || p.x < X0 - 0.05 || p.y < Y0 || p.y > Y1 || p.age > p.max || solidAt(p.x, p.y)) { resetParticle(p, false); continue; }
      if (p.n < TRAIL) { p.hx[p.n] = p.x; p.hy[p.n] = p.y; p.n++; }
      else { p.hx.copyWithin(0, 1); p.hy.copyWithin(0, 1); p.hx[TRAIL - 1] = p.x; p.hy[TRAIL - 1] = p.y; }
      p.b = bucketOf(cpOf(flowAt(p.x, p.y, tau, false)));
    }
  }

  // Trails are drawn in three segments (old → new) with rising opacity so they fade like streaks.
  function drawParticles() {
    ctx.lineWidth = 1.2 * dpr;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const cuts = [0, Math.floor(TRAIL * 0.4), Math.floor(TRAIL * 0.75), TRAIL];
    for (let b = 0; b < NB; b++) {
      for (let seg = 0; seg < 3; seg++) {
        ctx.beginPath();
        for (let i = 0; i < parts.length; i++) {
          const p = parts[i];
          if (p.b !== b || p.n < 2) continue;
          const off = TRAIL - p.n; // young particles: map their points onto the newest segments
          const a = Math.max(cuts[seg] - off, 0), e = Math.min(cuts[seg + 1] - off, p.n - 1);
          if (e - a < 1) continue;
          ctx.moveTo(sx(p.hx[a]), sy(p.hy[a]));
          for (let k = a + 1; k <= e; k++) ctx.lineTo(sx(p.hx[k]), sy(p.hy[k]));
        }
        ctx.strokeStyle = BUCKET[b][seg];
        ctx.stroke();
      }
    }
  }

  function arrow(x0, y0, x1, y1, color, width, head) {
    const ang = Math.atan2(y1 - y0, x1 - x0), len = Math.hypot(x1 - x0, y1 - y0);
    if (len < 0.5) return;
    const hh = Math.min(head, len * 0.6);
    ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = width;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 - Math.cos(ang) * hh * 0.7, y1 - Math.sin(ang) * hh * 0.7); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - Math.cos(ang - 0.42) * hh, y1 - Math.sin(ang - 0.42) * hh);
    ctx.lineTo(x1 - Math.cos(ang + 0.42) * hh, y1 - Math.sin(ang + 0.42) * hh);
    ctx.closePath(); ctx.fill();
  }

  function drawBody() {
    ctx.beginPath();
    body.pts.forEach((q, i) => (i ? ctx.lineTo(sx(q[0]), sy(q[1])) : ctx.moveTo(sx(q[0]), sy(q[1]))));
    ctx.closePath();
    const g = ctx.createLinearGradient(0, sy(body.ymax), 0, sy(body.ymin));
    g.addColorStop(0, "#22335c"); g.addColorStop(1, "#0f182e");
    ctx.fillStyle = g; ctx.fill();
    ctx.strokeStyle = "rgba(255,200,61,.85)"; ctx.lineWidth = 1.5 * dpr; ctx.stroke();
    if (body.kind === "sphere") {
      ctx.strokeStyle = "rgba(255,200,61,.3)"; ctx.lineWidth = 1 * dpr;
      ctx.beginPath(); ctx.ellipse(sx(0), sy(0), 0.5 * body.scale * S, 0.16 * body.scale * S, 0, 0, 2 * PI); ctx.stroke();
    }
    if (body.kind === "airfoil") { // chord line + quarter-chord pivot
      ctx.fillStyle = "rgba(255,255,255,.7)";
      ctx.beginPath(); ctx.arc(sx(0), sy(0), 2.2 * dpr, 0, 2 * PI); ctx.fill();
    }
  }

  function drawSurface() {
    const scale = 0.11;
    body.samples.forEach((sm) => {
      const f = flowAt(sm.x + sm.nx * 1.8 * DX, sm.y + sm.ny * 1.8 * DY, tau, false);
      const cp = cpOf(f);
      const len = clamp(Math.abs(cp), 0, 1.6) * scale;
      if (len < 0.012) return;
      const col = cp > 0 ? "rgba(255,110,100,.95)" : "rgba(90,160,255,.95)";
      let x0, y0, x1, y1;
      if (cp > 0) { x0 = sm.x + sm.nx * (len + 0.02); y0 = sm.y + sm.ny * (len + 0.02); x1 = sm.x + sm.nx * 0.02; y1 = sm.y + sm.ny * 0.02; }
      else { x0 = sm.x + sm.nx * 0.02; y0 = sm.y + sm.ny * 0.02; x1 = sm.x + sm.nx * (len + 0.02); y1 = sm.y + sm.ny * (len + 0.02); }
      arrow(sx(x0), sy(y0), sx(x1), sy(y1), col, 1.3 * dpr, 5 * dpr);
    });
  }

  function drawForces() {
    if (state.v <= 0) return;
    const qref = 0.5 * 1.225 * 35 * 35;
    const k = (1.1 * phys.q) / qref; // arrow length ∝ C·q ∝ v²
    const ox = body.ac[0], oy = body.ac[1];
    const maxL = 0.95;
    const lenL = clamp(phys.CL * k, -maxL, maxL), lenD = clamp(phys.CD * k, 0, 1.6);
    ctx.font = 600 + " " + 12 * dpr + "px 'JetBrains Mono', monospace";
    ctx.textBaseline = "middle";
    const label = (txt, x, y, col) => {
      const w = ctx.measureText(txt).width, pad = 5 * dpr, h = 18 * dpr;
      ctx.fillStyle = "rgba(6,10,20,.82)";
      ctx.fillRect(x - pad, y - h / 2, w + pad * 2, h);
      ctx.fillStyle = col; ctx.fillText(txt, x, y);
    };
    if (Math.abs(lenL) > 0.004) {
      arrow(sx(ox), sy(oy), sx(ox), sy(oy + lenL), "#ffc83d", 3 * dpr, 12 * dpr);
      const txt = "F_L = " + fmtForce(phys.FL) + (Math.abs(phys.CL * k) > maxL ? " ⇡" : "");
      // upward lift: label right of the arrow tip; downward lift: label left, below the tip (keeps clear of F_D)
      const lx = lenL > 0 ? sx(ox) + 10 * dpr : sx(ox) - 14 * dpr - ctx.measureText(txt).width;
      label(txt, lx, sy(oy + lenL) + (lenL > 0 ? 4 : 12) * dpr, "#ffc83d");
    }
    if (lenD > 0.004) {
      arrow(sx(ox), sy(oy), sx(ox + lenD), sy(oy), "#ff4d5e", 3 * dpr, 12 * dpr);
      const tx = Math.max(sx(ox + lenD) + 10 * dpr, sx(body.xmax) + 10 * dpr);
      label("F_D = " + fmtForce(phys.FD) + (phys.CD * k > 1.6 ? " ⇢" : ""), tx, sy(oy), "#ff4d5e");
    }
  }

  function drawFreestream() {
    ctx.fillStyle = "rgba(148,162,198,.55)";
    ctx.font = 11 * dpr + "px 'JetBrains Mono', monospace";
    ctx.textBaseline = "alphabetic";
    const y = Hpx - 12 * dpr;
    ctx.fillText("v∞ = " + state.v.toFixed(state.v < 10 ? 2 : 1) + " m/s  →", 12 * dpr, y);
  }

  function render() {
    ctx.fillStyle = "rgb(4,8,17)";
    ctx.fillRect(0, 0, Wpx, Hpx);
    if (ui.field.checked) {
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(heat, 0, 0, NX, NY, sx(X0 - DX / 2), sy(Y1 + DY / 2), (X1 - X0 + DX) * S, (Y1 - Y0 + DY) * S);
    }
    if (ui.particles.checked) drawParticles();
    drawBody();
    if (ui.surface.checked && state.v > 0) drawSurface();
    if (ui.forces.checked) drawForces();
    drawFreestream();
    if (state.v <= 0) {
      ctx.fillStyle = "rgba(6,10,20,.55)"; ctx.fillRect(0, 0, Wpx, Hpx);
      ctx.fillStyle = "#e8eeff"; ctx.font = 600 + " " + 18 * dpr + "px 'Space Grotesk', sans-serif";
      ctx.textAlign = "center"; ctx.fillText("Tunnel off: raise the air velocity", Wpx / 2, Hpx / 2); ctx.textAlign = "left";
    }
  }

  // ------------------------------------------------------------------
  // Formatting
  // ------------------------------------------------------------------
  const SUP = { "-": "⁻", 0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹" };
  function sci(x, d) {
    if (!isFinite(x)) return "—";
    if (x === 0) return "0";
    const e = Math.floor(Math.log10(Math.abs(x)));
    let m = x / Math.pow(10, e);
    return m.toFixed(d == null ? 2 : d) + " × 10" + String(e).split("").map((c) => SUP[c]).join("");
  }
  function num(x, sig) {
    if (!isFinite(x)) return "—";
    const a = Math.abs(x);
    if (a === 0) return "0";
    if (a >= 1e5 || a < 1e-3) return sci(x, 2);
    if (a >= 1000) return x.toFixed(0);
    if (a >= 100) return x.toFixed(1);
    return Number(x.toPrecision(sig || 3)).toString();
  }
  function fmtForce(f) { return Math.abs(f) >= 1e4 ? num(f / 1000) + " kN" : num(f) + " N"; }
  function fmtPower(p) { return Math.abs(p) >= 1e6 ? num(p / 1e6) + " MW" : Math.abs(p) >= 1e4 ? num(p / 1000) + " kW" : num(p) + " W"; }
  function fmtRe(re) { return re >= 1e4 ? sci(re, 2) : re >= 10 ? Math.round(re).toLocaleString() : num(re); }
  const REGIME = { lam: ["Laminar", "regime-lam"], tr: ["Transitional", "regime-tr"], tu: ["Turbulent", "regime-tu"] };

  // ------------------------------------------------------------------
  // UI
  // ------------------------------------------------------------------
  const ui = {
    v: $("in-v"), alt: $("in-alt"), aoa: $("in-aoa"), L: $("in-L"), b: $("in-b"), e: $("in-e"),
    field: $("t-field"), particles: $("t-particles"), surface: $("t-surface"), forces: $("t-forces")
  };
  const shapeBtns = document.querySelectorAll(".shape-btn");

  function paintRange(el) {
    const p = ((el.value - el.min) / (el.max - el.min)) * 100;
    el.style.setProperty("--p", p + "%");
  }

  let body = buildBody(state.shape, state.aoa);
  let phys = computePhysics(state);
  let needSolve = { cold: true }, heatDirty = true, lastKey = "";

  function syncInputs() {
    ui.v.value = state.v; ui.alt.value = state.alt; ui.aoa.value = state.aoa; ui.L.value = state.L; ui.b.value = state.b; ui.e.value = state.e;
    shapeBtns.forEach((b) => b.setAttribute("aria-pressed", b.dataset.shape === state.shape ? "true" : "false"));
  }

  function update(geoChanged, coldSolve) {
    const s = SHAPES[state.shape];
    if (geoChanged) {
      body = buildBody(state.shape, state.aoa);
      buildMask(body);
    }
    phys = computePhysics(state);
    const newPsiB = -0.13 * phys.CL;
    if (geoChanged || Math.abs(newPsiB - psiB) > 0.002) {
      psiB = newPsiB;
      needSolve = { cold: !!coldSolve || (needSolve && needSolve.cold) };
    }
    updateWake(body, phys);
    heatDirty = true;

    // Control visibility / labels
    const sym = s.kind === "cylinder" || s.kind === "sphere";
    $("c-aoa").classList.toggle("disabled", sym);
    $("aoa-note").textContent = sym ? "Symmetric body: rotation has no effect" : s.kind === "airfoil" ? "Nose-up rotation about the quarter chord" : "Rotation about the body centre";
    $("c-span").classList.toggle("disabled", !(s.kind === "airfoil" || s.kind === "cylinder"));
    $("c-e").classList.toggle("disabled", s.kind !== "airfoil");
    $("lbl-L").textContent = s.Llabel + " (characteristic L)";
    $("lbl-b").textContent = s.kind === "cylinder" ? "Cylinder length b" : "Wingspan b";

    // Outputs
    const atm = phys.atm, v = state.v, on = v > 0;
    $("o-v").textContent = v.toFixed(v < 10 ? 2 : 1) + " m/s";
    $("o-alt").textContent = Number(state.alt).toLocaleString() + " m";
    $("o-atm").textContent = "T = " + (atm.T - 273.15).toFixed(1) + " °C · P = " + (atm.P / 1000).toFixed(1) + " kPa";
    $("o-aoa").textContent = (sym ? 0 : state.aoa).toFixed(1) + "°";
    $("o-L").textContent = state.L.toFixed(2) + " m";
    $("o-b").textContent = state.b.toFixed(1) + " m";
    $("o-ar").textContent = s.kind === "airfoil" ? "AR = b²/S = " + (state.b / state.L).toFixed(2) + " · S = " + num(state.b * state.L) + " m²" : "Frontal area A = D·b = " + num(state.b * state.L) + " m²";
    $("o-e").textContent = state.e.toFixed(2);
    Object.keys(ui).forEach((k) => { if (ui[k].type === "range") paintRange(ui[k]); });

    $("m-rho").innerHTML = atm.rho.toFixed(3) + "<small>kg/m³</small>";
    $("m-rho-s").textContent = "ISA at " + Number(state.alt).toLocaleString() + " m";
    $("m-mu").innerHTML = sci(atm.mu, 2) + "<small>Pa·s</small>";
    $("m-q").innerHTML = num(phys.q) + "<small>Pa</small>";
    $("m-re").textContent = on ? fmtRe(phys.Re) : "0";
    $("m-re-s").textContent = on ? REGIME[phys.regime][0] : "no flow";
    $("m-cd").textContent = on ? num(phys.CD, 3) : "—";
    $("m-cd-s").textContent = phys.crisis ? "drag crisis!" : SHAPES[state.shape].kind === "airfoil" ? "profile + induced" : "total";
    $("m-cl").textContent = on ? num(phys.CL, 3) : "—";
    $("m-cl-s").textContent = phys.note;
    $("m-cdi").textContent = phys.AR ? (on ? num(phys.CDi, 3) : "—") : "n/a";
    $("m-cdi-s").innerHTML = phys.AR ? "AR = " + phys.AR.toFixed(2) + ", e = " + state.e.toFixed(2) : "finite wings only";
    $("m-ld").textContent = on && (phys.lifting || phys.AR) ? num(phys.LD, 3) : on ? "0" : "—";
    $("m-fd").textContent = fmtForce(phys.FD);
    $("m-fd-s").textContent = "A = " + num(phys.A) + " m² (" + phys.areaNote + ")";
    $("m-fl").textContent = fmtForce(phys.FL);
    $("m-fl-s").textContent = "≈ " + num(Math.abs(phys.FL) / 9.81) + " kg-force";
    $("m-p").textContent = fmtPower(phys.P);
    $("m-p-s").textContent = on ? "≈ " + num(phys.P / 745.7) + " hp" : "to overcome drag";
    const d = ((body.ymax - body.ymin) / body.scale) * state.L; // projected height in metres
    const fShed = on && phys.shed > 0.1 ? (0.2 * v) / d : null;
    $("m-f").innerHTML = fShed ? num(fShed) + "<small>Hz</small>" : "—";

    // HUD
    $("hud-shape").innerHTML = "<b>" + s.name + "</b>";
    $("hud-re").innerHTML = "Re = <b>" + (on ? fmtRe(phys.Re) : "0") + "</b>";
    const rg = $("hud-regime");
    rg.className = "hud-pill " + (on ? REGIME[phys.regime][1] : "");
    rg.textContent = on ? REGIME[phys.regime][0] : "No flow";
    const al = $("hud-alert");
    let alert = "";
    if (on && phys.stall > 0.5 && s.kind === "airfoil") alert = "STALL";
    else if (on && phys.crisis) alert = "Drag crisis";
    else if (on && phys.Re < 1) alert = "Creeping (Stokes) flow";
    al.style.display = alert ? "" : "none";
    al.textContent = alert;

    liveEquations(fShed, d);
  }

  function liveEquations(fShed, d) {
    const atm = phys.atm, v = state.v, s = SHAPES[state.shape];
    const B = (x) => "<b>" + x + "</b>";
    const rows = [];
    rows.push(["Air density", "ρ = P / (R<sub>d</sub>·T) = " + num(atm.P, 4) + " / (287.05 × " + atm.T.toFixed(2) + ") = " + B(atm.rho.toFixed(3) + " kg/m³")]);
    rows.push(["Reynolds number", "Re = ρvL / μ = " + atm.rho.toFixed(3) + " × " + num(v) + " × " + state.L.toFixed(2) + " / " + sci(atm.mu, 2) + " = " + B(fmtRe(phys.Re)) + (v > 0 ? " → " + REGIME[phys.regime][0].toLowerCase() : "")]);
    rows.push(["Drag force", "F<sub>D</sub> = ½ρv²C<sub>D</sub>A = 0.5 × " + atm.rho.toFixed(3) + " × " + num(v) + "² × " + num(phys.CD, 3) + " × " + num(phys.A) + " = " + B(fmtForce(phys.FD))]);
    if (phys.lifting || phys.AR) rows.push(["Lift force", "F<sub>L</sub> = ½ρv²C<sub>L</sub>A = 0.5 × " + atm.rho.toFixed(3) + " × " + num(v) + "² × " + num(phys.CL, 3) + " × " + num(phys.A) + " = " + B(fmtForce(phys.FL))]);
    if (phys.AR) rows.push(["Induced drag", "C<sub>D,i</sub> = C<sub>L</sub>² / (π·AR·e) = " + num(phys.CL, 3) + "² / (π × " + phys.AR.toFixed(2) + " × " + state.e.toFixed(2) + ") = " + B(num(phys.CDi, 3)) + " &nbsp;(" + (phys.CD > 0 ? Math.round((phys.CDi / phys.CD) * 100) : 0) + "% of total drag)"]);
    else rows.push(["Induced drag", "<span style='color:var(--muted)'>" + s.name + " is not a finite wing, so there is no C<sub>L</sub>²/(π·AR·e) term.</span>"]);
    rows.push(["Power", "P = F<sub>D</sub>·v = " + fmtForce(phys.FD) + " × " + num(v) + " m/s = " + B(fmtPower(phys.P))]);
    rows.push(["Vortex shedding", fShed ? "f = St·v / d = 0.2 × " + num(v) + " / " + num(d) + " m = " + B(num(fShed) + " Hz") : "<span style='color:var(--muted)'>No periodic shedding in this configuration (attached flow or Re too low).</span>"]);
    $("live-eq").innerHTML = rows.map((r) => '<div class="row"><div class="lbl">' + r[0] + '</div><div class="ex">' + r[1] + "</div></div>").join("");
  }

  // Events
  ["v", "alt", "aoa", "L", "b", "e"].forEach((k) => {
    ui[k].addEventListener("input", () => {
      state[k] = parseFloat(ui[k].value);
      update(k === "aoa", false);
    });
  });
  shapeBtns.forEach((btn) => btn.addEventListener("click", () => {
    state.shape = btn.dataset.shape;
    syncInputs();
    update(true, true);
    initParticles();
  }));
  document.querySelectorAll(".mini-btns").forEach((g) => {
    const target = g.getAttribute("data-for");
    g.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => {
      const key = target.replace("in-", "");
      state[key] = parseFloat(b.dataset.val);
      ui[key].value = state[key];
      update(false, false);
    }));
  });
  ["field", "particles", "surface", "forces"].forEach((k) => ui[k].addEventListener("change", () => { if (state.paused) render(); }));
  $("btn-pause").addEventListener("click", () => {
    state.paused = !state.paused;
    $("btn-pause").textContent = state.paused ? "Resume" : "Pause";
  });
  $("btn-reset").addEventListener("click", () => {
    Object.assign(state, DEFAULT);
    syncInputs(); update(true, true); initParticles();
  });

  // Hover probe
  const probe = $("probe"), wrap = $("canvas-wrap");
  canvas.addEventListener("mousemove", (ev) => {
    const r = canvas.getBoundingClientRect();
    const px = ev.clientX - r.left, py = ev.clientY - r.top;
    const x = X0 + (px / r.width) * (X1 - X0), y = Y1 - (py / r.height) * (Y1 - Y0);
    let html;
    if (inside(body.pts, x, y)) html = "<b>Solid body</b>";
    else {
      const f = flowAt(x, y, tau, false);
      const cp = cpOf(f);
      const sp = Math.hypot(f.u, f.v) * state.v;
      const p = phys.atm.P + cp * phys.q;
      html = "|u| <b>" + num(sp) + " m/s</b> · C<sub>p</sub> <b>" + cp.toFixed(2) + "</b><br>p <b>" + (p / 1000).toFixed(3) + " kPa</b>" + (f.w > 0.15 ? " · <b>wake</b>" : "");
    }
    probe.innerHTML = html;
    probe.style.display = "block";
    const left = Math.min(px + 14, r.width - probe.offsetWidth - 6);
    probe.style.left = left + "px";
    probe.style.top = Math.max(py - 44, 6) + "px";
  });
  canvas.addEventListener("mouseleave", () => { probe.style.display = "none"; });

  // Experiments
  const EXPERIMENTS = [
    { t: "Balsa glider cruise", d: "Glider-scale wing at Re ≈ 1.2 × 10⁵. Sweep α from 0° to 10° and find the angle with the best L/D.", s: { shape: "naca4412", v: 12, alt: 0, aoa: 4, L: 0.15, b: 1.2, e: 0.85 } },
    { t: "Stall the wing", d: "Raise α slowly from 12° to 22°. Watch C_L collapse, drag jump and the wake explode off the upper surface.", s: { shape: "naca0012", v: 25, alt: 0, aoa: 20, L: 0.3, b: 1.5, e: 0.85 } },
    { t: "Cylinder drag crisis", d: "Slowly raise v to 30 m/s. Near Re ≈ 3 × 10⁵ the boundary layer turns turbulent and C_D drops by about 70%.", s: { shape: "cylinder", v: 8, alt: 0, aoa: 0, L: 0.3, b: 1, e: 0.85 } },
    { t: "Laminar vortex street", d: "A thin wire in a gentle breeze, Re ≈ 70: a clean Kármán street. Lower v until shedding stops (Re < 47).", s: { shape: "cylinder", v: 0.1, alt: 0, aoa: 0, L: 0.01, b: 1, e: 0.85 } },
    { t: "Thin air at 10 km", d: "Airliner-like wing section. Switch altitude between sea level and 10 km: ρ falls to a third, and so does lift.", s: { shape: "naca4412", v: 100, alt: 10000, aoa: 3, L: 2, b: 10, e: 0.9 } },
    { t: "The power of streamlining", d: "Compare this teardrop's C_D with the flat plate and cylinder at the same speed. Streamlining cuts drag by about 20×.", s: { shape: "teardrop", v: 30, alt: 0, aoa: 0, L: 0.3, b: 1, e: 0.85 } },
    { t: "Aspect ratio & induced drag", d: "Stretch the span from 0.6 m to 4 m. Induced drag falls as AR grows, which is why gliders have long wings.", s: { shape: "naca4412", v: 20, alt: 0, aoa: 6, L: 0.3, b: 0.6, e: 0.8 } },
    { t: "Smooth golf ball", d: "A smooth ball at drive speed sits just below the crisis (C_D ≈ 0.4). Dimples trip turbulence early so real balls fly further.", s: { shape: "sphere", v: 70, alt: 0, aoa: 0, L: 0.04, b: 1, e: 0.85 } }
  ];
  const expWrap = $("experiments");
  expWrap.innerHTML = EXPERIMENTS.map((x, i) =>
    '<button class="card lift exp" data-i="' + i + '"><span class="tag c">' + SHAPES[x.s.shape].name + "</span><h3 style='margin-top:12px'>" + x.t + "</h3><p>" + x.d.replace(/C_L/g, "C<sub>L</sub>").replace(/C_D/g, "C<sub>D</sub>") + "</p><div class='go'>Load setup →</div></button>"
  ).join("");
  expWrap.querySelectorAll(".exp").forEach((b) => b.addEventListener("click", () => {
    Object.assign(state, EXPERIMENTS[+b.dataset.i].s);
    syncInputs(); update(true, true); initParticles();
    wrap.scrollIntoView({ behavior: "smooth", block: "center" });
  }));

  // ------------------------------------------------------------------
  // Main loop
  // ------------------------------------------------------------------
  function frame() {
    if (needSolve) {
      solve(needSolve.cold ? 700 : 160, needSolve.cold);
      needSolve = null;
      heatDirty = true;
    }
    if (heatDirty) { computeHeat(); heatDirty = false; }
    if (!state.paused) stepParticles();
    render();
    requestAnimationFrame(frame);
  }

  window.addEventListener("resize", () => {
    const w = canvas.clientWidth;
    if (Math.abs(w * Math.min(window.devicePixelRatio || 1, 2) - Wpx) > 2) { resize(); }
  });

  // Shareable setups: wind-tunnel.html?shape=cylinder&v=8&L=0.3&alt=0&aoa=0&b=1&e=0.85
  try {
    const qs = new URLSearchParams(location.search);
    if (SHAPES[qs.get("shape")]) state.shape = qs.get("shape");
    ["v", "alt", "aoa", "L", "b", "e"].forEach((k) => {
      const val = parseFloat(qs.get(k));
      if (isFinite(val)) state[k] = clamp(val, parseFloat(ui[k].min), parseFloat(ui[k].max));
    });
  } catch (err) { /* ignore malformed query */ }

  resize();
  syncInputs();
  body = buildBody(state.shape, state.aoa);
  buildMask(body);
  update(true, true);
  solve(700, true); needSolve = null;
  initParticles();
  // warm the trails so the first frame isn't empty
  for (let i = 0; i < 90; i++) stepParticles();
  requestAnimationFrame(frame);

  // Expose for debugging in the console
  window.JetstreamTunnel = { state, computePhysics, atmosphere };
})();

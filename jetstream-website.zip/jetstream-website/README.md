# JetStream Aerospace Club website

The website for JetStream, Heritage's first aerospace club. It is a static site (plain HTML, CSS and JavaScript) with no build step.

## Pages

| File | Page |
|---|---|
| `index.html` | Home |
| `about.html` | About Us: mission, how the club works, club leaders, why join |
| `curriculum.html` | Foundation / Intermediate / Advanced levels, projects, culmination project |
| `projects.html` | Flight experiments and the culmination showcase |
| `lectures.html` | Guest lectures (upcoming and past, managed by admins) |
| `members.html` | Club leaders and the public member directory |
| `blog.html` | Club blog (posts written by admins) |
| `wind-tunnel.html` | Interactive wind tunnel simulator |
| `research.html` | Research Hub bibliography (linked from the footer) |
| `join.html` | Create a member account |
| `login.html` | Sign in |
| `admin.html` | Admin dashboard: add or delete members, change roles, add or delete lectures and posts |

## Quick edits

| What | Where |
|---|---|
| Club leaders, social media links, school name | `js/config.js` |
| Leader photos | put images in `assets/team/` and set `photo` in `js/config.js` |
| Curriculum topics | `js/curriculum-data.js` |
| Colours | top of `css/style.css` (`--accent` yellow, `--red` red) |
| Nav and footer | `js/main.js` |

## Preview locally

```powershell
cd C:\Users\admin\jetstream-website
py -m http.server 8080
# open http://localhost:8080
```

## Accounts: preview mode vs live

`js/config.js` has `backend: "local"`. In this **preview mode**, accounts are stored only in the browser you are using. That is enough to try every feature. Test admin login: `admin@jetstream.local` / `jetstream123`.

For the **live site**, switch to Firebase so accounts are real, shared and secure. It is free on the Spark plan.

1. Go to https://console.firebase.google.com, choose **Add project** (e.g. "jetstream-club"), then **Add app → Web**. Copy `apiKey`, `authDomain`, `projectId` and `appId` into `js/config.js` → `firebase`, and set `backend: "firebase"`.
2. **Build → Authentication → Get started → Email/Password → Enable.**
3. **Build → Firestore Database → Create database** (production mode). Then open **Rules**, paste the contents of `firestore.rules`, and click **Publish**.
4. **Make yourself the first admin:** sign up on the site, then in Firestore open `members` → your document → change `role` from `member` to `admin`. From then on, you can promote others from the Admin page.
5. **Authentication → Settings → Authorized domains:** add your domain (e.g. `jetstreamclub.org`) and your Netlify URL.

Note: deleting a member in the Admin page removes their club record and directory listing, and they can no longer use the club features. Their Firebase login itself can be fully removed in **Firebase → Authentication** if needed.

## Hosting + a domain bought on Wix

**Yes, a Wix domain works.** Buy the domain on Wix, host the site on Netlify (free), and point the domain at Netlify:

1. Deploy: go to https://app.netlify.com/drop and drag the `jetstream-website` folder in. You get a `something.netlify.app` URL.
2. In Netlify: **Domain management → Add a domain** → enter your Wix domain. Netlify shows the DNS records it needs.
3. In Wix: **Domains → (your domain) → Manage DNS records**, then:
   - **A record** for `@` → `75.2.60.5` (Netlify's load balancer; replace the existing Wix A records)
   - **CNAME** for `www` → `your-site.netlify.app`
4. Wait for DNS to update (minutes to a few hours). Netlify then issues free HTTPS automatically.

Things to know:
- The site is custom code, so it can't be built inside the Wix editor. Wix provides the **domain name** only; the site itself lives on Netlify.
- Wix domains usually cost more to renew than Cloudflare or Namecheap. You can transfer the domain away later (after 60 days) without changing the website.

## Simulator: shareable setups

`wind-tunnel.html?shape=naca0012&v=25&aoa=20` (parameters: `shape`, `v`, `alt`, `aoa`, `L`, `b`, `e`).
